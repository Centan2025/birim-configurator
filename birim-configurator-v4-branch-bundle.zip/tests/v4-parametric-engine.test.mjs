import test from "node:test";
import assert from "node:assert/strict";
import {
  DOOR_MECHANISM_SPECS,
  inferDoorSystemIdFromType,
  calculateBayWidths,
  calculateNetInnerHeight,
  calculateNetInnerDepth,
  calculateBackPanelEngagementMm,
  calculateShelfDeflectionMm,
  generateModuleGeometry,
  generateProjectBOM,
  moveModuleInPlan2D,
  validateSpatialAndKitchenEngineering,
  updateModuleQuickParams,
  setBayDoorAndHandle,
  addOrUpdateBayShelf,
  removeBayShelf,
  addOrUpdateBayDrawer,
  serializeProjectSnapshot,
  deserializeProjectSnapshot,
  computeUnifiedWorkspaceState,
} from "../dist-test/birim-engine-v4.mjs";

function createSampleWardrobeModule(overrides = {}) {
  return {
    id: "mod_wardrobe_1",
    name: "Birim V4 2 Bölmeli Gardırop",
    code: "WRD-1800-2200-600",
    category: "wardrobe",
    dimensions: { width: 1800, height: 2200, depth: 600 },
    position: { x: 200, y: 0, z: 0 },
    rotationY: 0,
    carcass: {
      panelThickness: 18,
      backPanelThickness: 8,
      backMountType: "grooved",
      backGrooveOffsetMm: 18,
      plinthHeight: 80,
      bodyMaterialId: "mat_oak_natural_18",
      doorMaterialId: "mat_lacquer_sand_18",
      doorPerimeterGap: 2,
      verticalDividerCount: 1,
    },
    bays: [
      {
        id: "bay_1",
        index: 0,
        shelves: [
          { id: "sh_1", type: "adjustable" },
          { id: "sh_2", type: "fixed", yPositionMm: 1100 },
        ],
        drawers: [
          { id: "drw_1", heightMm: 200, handleProfileId: "HRD_HANDLE_BAR_160" },
          { id: "drw_2", heightMm: 200, handleProfileId: "HRD_HANDLE_BAR_160" },
        ],
        hangingRails: [{ id: "rail_1", yOffsetFromTopMm: 80 }],
        accessories: [{ id: "acc_1", type: "trouser_rack", yPositionMm: 750, heightMm: 80 }],
        doors: {
          type: "single_left",
          handleProfileId: "HRD_HANDLE_LONG_320",
        },
      },
      {
        id: "bay_2",
        index: 1,
        shelves: [{ id: "sh_3", type: "adjustable" }],
        drawers: [],
        hangingRails: [{ id: "rail_2", yOffsetFromTopMm: 80 }],
        doors: {
          type: "single_right",
          handleProfileId: "HRD_HANDLE_LONG_320",
        },
      },
    ],
    ...overrides,
  };
}

// ---------------------------------------------------------------------------
// 1. FAZ A: Parametrik Ölçü ve Bağımlılık Testleri
// ---------------------------------------------------------------------------
test("FAZ A.1 — Kapalı Ölçü Zinciri (Dimension-Chain Closure): sum(bayWidths) + (N+1)*T === width", () => {
  const mod = createSampleWardrobeModule({
    dimensions: { width: 1750, height: 2200, depth: 600 },
    carcass: {
      panelThickness: 18,
      backPanelThickness: 8,
      plinthHeight: 80,
      bodyMaterialId: "mat_oak",
      doorPerimeterGap: 2,
      verticalDividerCount: 2,
    },
    bays: [
      { id: "b1", index: 0, customWidthMm: 500, shelves: [], drawers: [], hangingRails: [] },
      { id: "b2", index: 1, shelves: [], drawers: [], hangingRails: [] },
      { id: "b3", index: 2, shelves: [], drawers: [], hangingRails: [] },
    ],
  });

  const bayWidths = calculateBayWidths(mod);
  assert.equal(bayWidths.length, 3);
  assert.equal(bayWidths[0], 500);
  const totalThickness = 4 * 18; // 2 side panels + 2 dividers = 72mm
  const sumAll = Number((bayWidths.reduce((a, b) => a + b, 0) + totalThickness).toFixed(2));
  assert.equal(sumAll, 1750, "Bölme genişlikleri ve dikme kalınlıkları toplamı tam dış genişliğe eşit olmalı");
});

test("FAZ A.2 — Genişlik, Yükseklik ve Derinlik Değiştiğinde Tüm Bağımlı Parçaların Yeniden Hesaplanması", () => {
  const mod1 = createSampleWardrobeModule();
  const geo1 = generateModuleGeometry(mod1);

  const leftSide1 = geo1.components.find((c) => c.role === "carcass_side_left");
  const bottom1 = geo1.components.find((c) => c.role === "carcass_bottom");
  const back1 = geo1.components.find((c) => c.role === "carcass_back");

  assert.equal(leftSide1.dimensions.height, 2200);
  assert.equal(bottom1.dimensions.width, 1800 - 2 * 18); // 1764mm

  // Grooved back panel engagement: e_g = min(8, 0.5*18) = 8mm per side (+16mm total)
  const expectedNetInnerH = 2200 - 80 - 2 * 18; // 2084mm
  assert.equal(geo1.netInnerHeight, expectedNetInnerH);
  assert.equal(back1.dimensions.width, 1764 + 16); // 1780mm
  assert.equal(back1.dimensions.height, expectedNetInnerH + 16); // 2100mm
  assert.equal(back1.position.y, 80 + 18 - 8); // 90mm (no collision with plinth!)

  // Resize module to 2400 x 2450 x 650
  const project = {
    id: "proj_1",
    name: "Test Project",
    version: 1,
    room: { width: 4000, height: 2800, depth: 3500 },
    modules: [mod1],
  };
  const updatedProject = updateModuleQuickParams(project, mod1.id, {
    width: 2400,
    height: 2450,
    depth: 650,
    verticalDividerCount: 2,
  });

  const geo2 = generateModuleGeometry(updatedProject.modules[0]);
  const bottom2 = geo2.components.find((c) => c.role === "carcass_bottom");
  const dividers2 = geo2.components.filter((c) => c.role === "carcass_divider");

  assert.equal(bottom2.dimensions.width, 2400 - 36); // 2364mm
  assert.equal(bottom2.dimensions.depth, 650);
  assert.equal(dividers2.length, 2);
  assert.equal(geo2.netInnerHeight, 2450 - 80 - 36); // 2334mm
  assert.equal(geo2.netInnerDepth, 650 - 18 - 8); // 624mm
});

test("FAZ A.3 — Euler-Bernoulli Raf Sehim (Deflection) Kontrolü", () => {
  const safeShelf = calculateShelfDeflectionMm(750, 550, 18);
  assert.equal(safeShelf.exceedsLimit, false);

  const wideShelf = calculateShelfDeflectionMm(1150, 400, 18);
  assert.equal(wideShelf.exceedsLimit, true, "1150mm açıklıklı 18mm raf sehim uyarısı üretmeli");
});

// ---------------------------------------------------------------------------
// 2. FAZ B: Kapak ve Kulp Sistemleri Testleri
// ---------------------------------------------------------------------------
test("FAZ B.1 — Kulp Görünürlüğü ve Doğru Kapak / Açılma Kenarı Konumlandırması", () => {
  const mod = createSampleWardrobeModule();
  const geo = generateModuleGeometry(mod);

  const doorLeaves = geo.components.filter((c) => c.role === "door_leaf");
  const doorHandles = geo.components.filter((c) => c.role === "door_handle");
  const drawerHandles = geo.components.filter((c) => c.role === "drawer_handle");

  assert.equal(doorLeaves.length, 2, "2 bölmede 2 tekil kapak üretilmeli");
  assert.equal(doorHandles.length, 2, "Her iki kapakta da seçilen kulp (door_handle) görünmeli");
  assert.equal(drawerHandles.length, 2, "Her iki çekmecede de kulp görünmeli");

  const leftHingedDoor = doorLeaves[0];
  const leftDoorHandle = doorHandles.find((h) => h.parentComponentId === leftHingedDoor.id);
  assert.equal(leftHingedDoor.doorHingeSide, "left");
  // Left-hinged door handle must be near its right (opening) edge!
  assert.ok(
    leftDoorHandle.position.x > leftHingedDoor.position.x + leftHingedDoor.dimensions.width * 0.75,
    "Sol menteşeli kapağın kulpu sağ (açılma) kenarında olmalı"
  );

  const rightHingedDoor = doorLeaves[1];
  const rightDoorHandle = doorHandles.find((h) => h.parentComponentId === rightHingedDoor.id);
  assert.equal(rightHingedDoor.doorHingeSide, "right", "single_right kapak sağ menteşeli olmalı");
  // Right-hinged door handle must be near its left (opening) edge!
  assert.ok(
    rightDoorHandle.position.x < rightHingedDoor.position.x + rightHingedDoor.dimensions.width * 0.25,
    "Sağ menteşeli kapağın kulpu sol (açılma) kenarında olmalı"
  );
});

test("FAZ B.2 — Menteşeli, Sürgülü, Katlanır ve Kalkar Kapak Kinematikleri + Doğrulanmamış Sistem Engeli", () => {
  // 1. Sliding 2-door mechanism
  const slidingMod = createSampleWardrobeModule({
    bays: [
      {
        id: "b1",
        index: 0,
        shelves: [],
        drawers: [],
        hangingRails: [],
        doors: { type: "sliding", handleProfileId: "HRD_HANDLE_RECESSED" },
      },
      {
        id: "b2",
        index: 1,
        shelves: [],
        drawers: [],
        hangingRails: [],
        doors: { type: "folding", handleProfileId: "HRD_HANDLE_BAR_160" },
      },
    ],
  });

  const closedGeo = generateModuleGeometry(slidingMod, { doorOpenAngleDeg: 0 });
  const openGeo = generateModuleGeometry(slidingMod, { doorOpenAngleDeg: 90 });

  const slidingClosed = closedGeo.components.filter((c) => c.role === "door_leaf" && c.bayIndex === 0);
  const slidingOpen = openGeo.components.filter((c) => c.role === "door_leaf" && c.bayIndex === 0);
  assert.equal(slidingClosed.length, 2, "Sürgülü sistem 2 kanat üretmeli");
  assert.ok(
    slidingOpen[0].position.x > slidingClosed[0].position.x,
    "Sürgülü ön kanat açıldığında X ekseninde kaymalı"
  );
  assert.equal(slidingOpen[0].rotation[1], 0, "Sürgülü kapak Y ekseninde dönmemeli");

  const foldingOpen = openGeo.components.filter((c) => c.role === "door_leaf" && c.bayIndex === 1);
  assert.equal(foldingOpen.length, 2, "Katlanır (bi-fold) sistem 2 kanat üretmeli");
  assert.ok(foldingOpen[0].rotation[1] < 0 && foldingOpen[1].rotation[1] > 0, "Katlanır kanatlar zıt açılarla katlanmalı");

  // 2. Lift-up door mechanism (Aventos HK-S)
  const liftMod = createSampleWardrobeModule({
    category: "wall",
    dimensions: { width: 900, height: 720, depth: 350 },
    carcass: {
      panelThickness: 18,
      backPanelThickness: 8,
      plinthHeight: 0,
      bodyMaterialId: "mat_white",
      doorPerimeterGap: 2,
      verticalDividerCount: 0,
    },
    bays: [
      {
        id: "b_wall",
        index: 0,
        shelves: [],
        drawers: [],
        hangingRails: [],
        doors: { type: "lift", handleProfileId: "HRD_HANDLE_BAR_160" },
      },
    ],
  });
  const liftOpenGeo = generateModuleGeometry(liftMod, { doorOpenAngleDeg: 90 });
  const liftLeaf = liftOpenGeo.components.find((c) => c.role === "door_leaf");
  assert.equal(liftLeaf.doorHingeSide, "top");
  assert.ok(liftLeaf.rotation[0] < -1.0, "Kalkar kapak üst menteşe ekseninde yukarı (-X) dönmeli");

  // 3. Unverified mechanism (pocket_retractable) must NOT fake movement and must emit warning
  const pocketMod = createSampleWardrobeModule({
    bays: [
      {
        id: "b1",
        index: 0,
        shelves: [],
        drawers: [],
        hangingRails: [],
        doors: { type: "pocket", handleProfileId: "HRD_HANDLE_BAR_160" },
      },
      {
        id: "b2",
        index: 1,
        shelves: [],
        drawers: [],
        hangingRails: [],
        doors: { type: "none" },
      },
    ],
  });
  const pocketGeo = generateModuleGeometry(pocketMod, { doorOpenAngleDeg: 90 });
  const pocketLeaf = pocketGeo.components.find((c) => c.role === "door_leaf");
  assert.equal(pocketLeaf.isMechanismVerified, false, "Pocket mekanizma doğrulanmamış olarak işaretlenmeli");
  assert.deepEqual(pocketLeaf.rotation, [0, 0, 0], "Doğrulanmamış mekanizma sahte açılma hareketi yapmamalı");
  assert.ok(pocketGeo.warnings.some((w) => w.includes("NOT VERIFIED")));
});

// ---------------------------------------------------------------------------
// 3. FAZ C: İç Donanım ve Çekmece/Raf/Askı Senkronizasyonu Testleri
// ---------------------------------------------------------------------------
test("FAZ C.1 — Çekmece Kasa Setback, Ray ve Raf/Kapak Ekleme-Silme-Konumlandırma", () => {
  let project = {
    id: "proj_int",
    name: "İç Donanım Testi",
    version: 1,
    room: { width: 3600, height: 2700, depth: 3000 },
    modules: [createSampleWardrobeModule()],
  };

  // Add a 3rd shelf with explicit yPositionMm = 1450mm
  project = addOrUpdateBayShelf(project, "mod_wardrobe_1", 0, {
    id: "sh_custom_3",
    type: "adjustable",
    yPositionMm: 1450,
  });

  // Add a 3rd drawer to bay 0
  project = addOrUpdateBayDrawer(project, "mod_wardrobe_1", 0, {
    id: "drw_3",
    heightMm: 180,
    handleProfileId: "HRD_HANDLE_BAR_160",
  });

  const state1 = computeUnifiedWorkspaceState(project, { drawerOpenMm: 300 });
  const geo1 = state1.geometries["mod_wardrobe_1"];

  const customShelf = geo1.components.find((c) => c.id === "sh_custom_3");
  assert.ok(customShelf, "Yeni eklenen raf 3D geometride bulunmalı");
  assert.equal(customShelf.position.y, 80 + 18 + 1450, "Raf tam olarak belirtilen yPositionMm kotunda konumlanmalı");

  // Verify drawer box starts strictly behind drawer front
  const drwFront = geo1.components.find((c) => c.id === "drw_3_front");
  const drwSide = geo1.components.find((c) => c.id === "drw_3_side_left");
  assert.equal(
    drwSide.position.z + drwSide.dimensions.depth,
    drwFront.position.z,
    "Çekmece kasasının ön ucu çekmece كپاğının iç yüzeyini aşmamalı"
  );

  // Verify upper door starts ABOVE the drawer stack (no overlap between drawers and door!)
  const bay0Door = geo1.components.find((c) => c.role === "door_leaf" && c.bayIndex === 0);
  assert.ok(
    bay0Door.position.y > drwFront.position.y + drwFront.dimensions.height,
    "Üst kapak çekmece grubunun üstünden başlamalı, çekmecelerle çakışmamalı"
  );

  // Remove shelf and verify both 3D and BOM update together
  const bomCountBefore = state1.bom.totalCutPiecesCount;
  project = removeBayShelf(project, "mod_wardrobe_1", 0, "sh_custom_3");
  const state2 = computeUnifiedWorkspaceState(project);
  assert.equal(state2.bom.totalCutPiecesCount, bomCountBefore - 1, "Raf silindiğinde BOM kesim listesi anında 1 azalmalı");
});

// ---------------------------------------------------------------------------
// 4. FAZ D: Plan (2D+3D) Senkronizasyonu ve Çakışma Doğrulaması Testleri
// ---------------------------------------------------------------------------
test("FAZ D.1 — 2D Planda Modül Taşıma/Döndürme ile 3D Konum Senkronizasyonu ve Manyetik Yapışma", () => {
  const modA = createSampleWardrobeModule({
    id: "mod_a",
    name: "Sol Modül",
    dimensions: { width: 1000, height: 2200, depth: 600 },
    position: { x: 0, y: 0, z: 0 },
  });
  const modB = createSampleWardrobeModule({
    id: "mod_b",
    name: "Sağ Modül",
    dimensions: { width: 800, height: 2200, depth: 600 },
    position: { x: 1500, y: 0, z: 100 },
  });

  let project = {
    id: "proj_plan",
    name: "Plan 2D+3D Test",
    version: 1,
    room: { width: 3600, height: 2700, depth: 3000, obstacles: [] },
    modules: [modA, modB],
  };

  // Drag mod_b in 2D plan to (1018, 12) -> within 35mm threshold of mod_a right edge (1000) and back wall (0)
  project = moveModuleInPlan2D(project, "mod_b", 1018, 12);
  const movedB = project.modules.find((m) => m.id === "mod_b");
  assert.equal(movedB.position.x, 1000, "Modül B, Modül A'nın sağ kenarına (1000mm) manyetik yapışmalı");
  assert.equal(movedB.position.z, 0, "Modül B arka duvara (z=0) manyetik yapışmalı");
});

test("FAZ D.2 — Duvar, Pencere, Kapı Süpürme Alanı, Kolon ve Geçiş Koridoru Çakışma Testleri", () => {
  const mod1 = createSampleWardrobeModule({
    id: "mod_1",
    name: "Ana Dolap",
    dimensions: { width: 1200, height: 2200, depth: 600 },
    position: { x: 100, y: 0, z: 0 },
  });
  const mod2Overlapping = createSampleWardrobeModule({
    id: "mod_2",
    name: "Çakışan Dolap",
    dimensions: { width: 1000, height: 2200, depth: 600 },
    position: { x: 900, y: 0, z: 0 }, // Overlaps mod1 (100..1300)
  });

  const projectWithCollisions = {
    id: "proj_collision",
    name: "Çakışma Testi",
    version: 1,
    room: {
      width: 3000,
      height: 2600,
      depth: 2500,
      obstacles: [
        {
          id: "col_1",
          type: "column",
          label: "Taşıyıcı Kolon K1",
          x: 150,
          y: 0,
          z: 0,
          width: 400,
          height: 2600,
          depth: 400,
        },
        {
          id: "win_1",
          type: "window",
          label: "Salon Penceresi P1",
          x: 1000,
          y: 900,
          z: 0,
          width: 1200,
          height: 1200,
          depth: 200,
        },
        {
          id: "door_1",
          type: "door",
          label: "Oda Giriş Kapısı",
          x: 100,
          y: 0,
          z: 300,
          width: 900,
          height: 2100,
          depth: 100,
          swingRadiusMm: 900,
        },
      ],
    },
    modules: [mod1, mod2Overlapping],
  };

  const validation = validateSpatialAndKitchenEngineering(projectWithCollisions);
  assert.equal(validation.isCompliant, false);
  const codes = validation.issues.map((i) => i.code);
  assert.ok(codes.includes("MODULE_COLLISION"), "Modül-modül çakışması tespit edilmeli");
  assert.ok(codes.includes("OBSTACLE_COLLISION"), "Kolon çakışması tespit edilmeli");
  assert.ok(codes.includes("WINDOW_OCCLUSION"), "Pencere önü kapanması tespit edilmeli");
  assert.ok(codes.includes("DOOR_SWING_COLLISION"), "Oda kapısı açılma alanı çakışması tespit edilmeli");
});

// ---------------------------------------------------------------------------
// 5. FAZ F: BOM, Kenar Bandı, CNC Delik ve Üretim Kapısı Tutarlılık Testleri
// ---------------------------------------------------------------------------
test("FAZ F.1 — BOM ile 3D Geometrinin Tek Kaynaktan Türetilmesi ve Panel Kesim Ölçüsü Doğruluğu", () => {
  const mod = createSampleWardrobeModule();
  const project = {
    id: "proj_bom",
    name: "BOM Doğrulama Projesi",
    version: 1,
    room: { width: 4000, height: 2800, depth: 3200 },
    modules: [mod],
  };

  const geo = generateModuleGeometry(mod);
  const bom = generateProjectBOM(project);

  // Metal hardware components in 3D must NOT leak into wooden cutPieces
  const hasHardwareInCutlist = bom.cutPieces.some(
    (p) =>
      p.role === "door_handle" ||
      p.role === "drawer_handle" ||
      p.role === "drawer_slide" ||
      p.role === "hanging_rail"
  );
  assert.equal(hasHardwareInCutlist, false, "Metal donanımlar ahşap kesim listesine (cutPieces) girmemeli");

  // Check Bottom Panel (carcass_bottom) dimensions — fixing the old min(height,depth)=18mm bug!
  const bottomPiece = bom.cutPieces.find((p) => p.role === "carcass_bottom");
  assert.equal(bottomPiece.finishedLengthMm, 1764);
  assert.equal(bottomPiece.finishedWidthMm, 600);
  assert.equal(bottomPiece.thicknessMm, 18);
  // Left + Right 1mm edgebanding deducted -> cutLengthMm = 1762mm, Top (front) 1mm deducted -> cutWidthMm = 599mm
  assert.equal(bottomPiece.cutLengthMm, 1762);
  assert.equal(bottomPiece.cutWidthMm, 599);

  // Check Right-Hinged Door CNC Hinge Cup Drilling (must be on right edge x = width - 22.5)
  const rightDoorPiece = bom.cutPieces.find(
    (p) => p.role === "door_leaf" && p.id.endsWith("_door_b2_1")
  );
  const hingeCupHoles = rightDoorPiece.drillingHoles.filter((h) => h.purpose === "hinge_cup");
  assert.equal(hingeCupHoles.length, 4, "2200mm yüksekliğindeki kapakta 4 adet 35mm menteşe tas deliği olmalı");
  assert.equal(
    hingeCupHoles[0].x,
    Number((rightDoorPiece.finishedWidthMm - 22.5).toFixed(2)),
    "Sağ menteşeli kapakta menteşe tas delikleri sağ kenardan 22.5mm içeride olmalı"
  );

  // Check Hardware BOM counts (2 door handles + 2 drawer handles + 8 hinges + 2 drawer slide pairs)
  const doorHandleHw = bom.hardwareItems.find((h) => h.id === "HRD_HANDLE_LONG_320");
  const drawerHandleHw = bom.hardwareItems.find((h) => h.id === "HRD_HANDLE_BAR_160");
  const hingeHw = bom.hardwareItems.find((h) => h.id === "HRD_HINGE_CLIPTOP_110");
  assert.equal(doorHandleHw.quantity, 2, "BOM'da 2 adet kapak kulpu yer almalı");
  assert.equal(drawerHandleHw.quantity, 2, "BOM'da 2 adet çekmece kulpu yer almalı");
  assert.equal(hingeHw.quantity, 8, "BOM'da 2 kapak x 4 = 8 adet frenli menteşe yer almalı");
  assert.equal(bom.productionGate.isReadyForErp, true, "Doğrulanmış model ERP aktarımına onay vermeli");
});

test("FAZ F.2 — Üretim Kapısı (Fail-Closed ERP Gate): Plaka Boyutu Aşımı veya Doğrulanmamış Mekanizmada ERP Engeli", () => {
  const oversizeMod = createSampleWardrobeModule({
    dimensions: { width: 3100, height: 2200, depth: 600 }, // Bottom/Top panel > 2780mm usable sheet length
  });
  const bom = generateProjectBOM({
    id: "proj_oversize",
    name: "Oversize Test",
    version: 1,
    room: { width: 4000, height: 2800, depth: 3200 },
    modules: [oversizeMod],
  });
  assert.equal(bom.productionGate.isReadyForErp, false, "Standart plaka boyunu aşan parça ERP onayını engellemeli");
  assert.ok(bom.productionGate.blockingErrors.length > 0);
});

// ---------------------------------------------------------------------------
// 6. Kaydetme/Yeniden Açma ve V2 Regresyon Testleri
// ---------------------------------------------------------------------------
test("FAZ E & V2 Regresyon — Proje Kaydetme/Yeniden Açma (Roundtrip) ve Tamamlayıcı V2 Modül Uyumluluğu", () => {
  const complementaryCountertop = {
    id: "comp_ct_1",
    name: "Kuvars Mutfak Tezgahı",
    category: "complementary",
    complementaryRole: "countertop",
    dimensions: { width: 2400, height: 30, depth: 620 },
    position: { x: 0, y: 870, z: 0 },
    carcass: {
      panelThickness: 30,
      backPanelThickness: 0,
      plinthHeight: 0,
      bodyMaterialId: "mat_quartz_calacatta",
      doorPerimeterGap: 0,
      verticalDividerCount: 0,
    },
    bays: [],
  };

  const originalProject = {
    id: "proj_roundtrip",
    name: "Birim V4 Kayıt Testi",
    version: 3,
    room: { width: 4200, height: 2800, depth: 3400 },
    modules: [createSampleWardrobeModule(), complementaryCountertop],
  };

  const json = serializeProjectSnapshot(originalProject);
  const restored = deserializeProjectSnapshot(json);

  assert.equal(restored.id, originalProject.id);
  assert.equal(restored.modules.length, 2);

  const stateBefore = computeUnifiedWorkspaceState(originalProject);
  const stateAfter = computeUnifiedWorkspaceState(restored);

  assert.equal(stateAfter.bom.totalCutPiecesCount, stateBefore.bom.totalCutPiecesCount);
  assert.equal(stateAfter.bom.totalPanelAreaM2, stateBefore.bom.totalPanelAreaM2);
  assert.equal(stateAfter.bom.totalHardwareCount, stateBefore.bom.totalHardwareCount);
});
