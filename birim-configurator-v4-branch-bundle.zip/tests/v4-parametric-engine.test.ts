import { describe, it, expect } from "vitest";
import {
  calculateBayWidths,
  calculateShelfDeflectionMm,
} from "../packages/core/src/rules";
import { generateModuleGeometry } from "../packages/geometry/src/mesh-generator";
import { generateProjectBOM } from "../packages/manufacturing/src/bom-generator";
import {
  moveModuleInPlan2D,
  validateSpatialAndKitchenEngineering,
} from "../apps/configurator/src/v3/engine/kitchenSpatialEngine";
import {
  updateModuleQuickParams,
  addOrUpdateBayShelf,
  removeBayShelf,
  serializeProjectSnapshot,
  deserializeProjectSnapshot,
} from "../apps/configurator/src/v3/adapter/useV3Adapter";

describe("Birim V4 Parametric Engine, Door/Handle Kinematics, 2D/3D Sync & BOM Suite", () => {
  it("enforces exact dimension-chain closure sum(bayWidths) + (N+1)*T === width", () => {
    const mod: any = {
      id: "m1",
      name: "Test Wardrobe",
      category: "wardrobe",
      dimensions: { width: 1750, height: 2200, depth: 600 },
      position: { x: 0, y: 0, z: 0 },
      carcass: {
        panelThickness: 18,
        backPanelThickness: 8,
        plinthHeight: 80,
        bodyMaterialId: "mat_oak",
        doorPerimeterGap: 2,
        verticalDividerCount: 2,
      },
      bays: [
        { id: "b1", index: 0, customWidthMm: 500, shelves: [], drawers: [], hangingRails: [] },
        { id: "b2", index: 1, shelves: [], drawers: [], hangingRails: [] },
        { id: "b3", index: 2, shelves: [], drawers: [], hangingRails: [] },
      ],
    };
    const bayWidths = calculateBayWidths(mod);
    const total = Number((bayWidths.reduce((a, b) => a + b, 0) + 4 * 18).toFixed(2));
    expect(total).toBe(1750);
  });

  it("generates door_handle on correct opening edge and keeps BOM 100% consistent with 3D geometry", () => {
    const mod: any = {
      id: "m2",
      name: "2-Bay Wardrobe",
      category: "wardrobe",
      dimensions: { width: 1800, height: 2200, depth: 600 },
      position: { x: 0, y: 0, z: 0 },
      carcass: {
        panelThickness: 18,
        backPanelThickness: 8,
        backMountType: "grooved",
        backGrooveOffsetMm: 18,
        plinthHeight: 80,
        bodyMaterialId: "mat_oak",
        doorMaterialId: "mat_sand",
        doorPerimeterGap: 2,
        verticalDividerCount: 1,
      },
      bays: [
        {
          id: "b1",
          index: 0,
          shelves: [{ id: "s1", type: "adjustable" }],
          drawers: [{ id: "d1", heightMm: 200, handleProfileId: "HRD_HANDLE_BAR_160" }],
          hangingRails: [],
          doors: { type: "single_left", handleProfileId: "HRD_HANDLE_LONG_320" },
        },
        {
          id: "b2",
          index: 1,
          shelves: [],
          drawers: [],
          hangingRails: [],
          doors: { type: "single_right", handleProfileId: "HRD_HANDLE_LONG_320" },
        },
      ],
    };

    const geo = generateModuleGeometry(mod);
    const doorHandles = geo.components.filter((c) => c.role === "door_handle");
    expect(doorHandles.length).toBe(2);

    const bom = generateProjectBOM({
      id: "p1",
      name: "Project",
      version: 1,
      room: { width: 4000, height: 2800, depth: 3200 },
      modules: [mod],
    });

    const bottomPiece = bom.cutPieces.find((p) => p.role === "carcass_bottom")!;
    expect(bottomPiece.finishedLengthMm).toBe(1764);
    expect(bottomPiece.finishedWidthMm).toBe(600);
    expect(bom.productionGate.isReadyForErp).toBe(true);
  });
});
