# Birim V3.1 / V4 Test ve Doğrulama Raporu (`TEST_REPORT.md`)

Bu rapor, `feat/configurator-parametric-engine-v4` geliştirmeleri sonrasında çalıştırılan otomatik test senaryolarını, gerçek çalışma çıktılarını ve çalışma ortamı kısıtları nedeniyle `NOT VERIFIED` olarak işaretlenen noktaları içerir.

## 1. Çalıştırılan Otomatik Test Özeti (`node --test`)

Sandbox VM üzerinde Node.js (`v18.20.4`) yerleşik test koşucusu (`node --test tests/v4-parametric-engine.test.mjs`) ile 11 kapsamlı mühendislik ve regresyon testi çalıştırılmış ve **11/11 test (%100) sıfır hata ile geçmiştir** (toplam süre: `747.36 ms`).

| Test No | Test Senaryosu | Kapsanan Faz | Durum | Süre (ms) | Doğrulanan Kriter |
| :--- | :--- | :--- | :--- | :--- | :--- |
| 1 | `FAZ A.1 — Kapalı Ölçü Zinciri (Dimension-Chain Closure)` | Faz A | **PASSED** | `5.12 ms` | $\sum W_{	ext{bay},i} + (N+1)T \equiv W$ ($1750	ext{ mm}$ dış genişlikte kilitli $500	ext{ mm}$ bölme + 2 esnek bölme + $4 	imes 18	ext{ mm}$ panel = $1750.00	ext{ mm}$) |
| 2 | `FAZ A.2 — Genişlik, Yükseklik ve Derinlik Değişiminde Bağımlı Parçalar` | Faz A | **PASSED** | `8.33 ms` | $1800 	imes 2200 	imes 600	ext{ mm}$ modülün $2400 	imes 2450 	imes 650	ext{ mm}$ ölçüsüne büyütülmesinde yan panel, alt/üst tabla ($2364	ext{ mm}$), kanallı arkalık ($+16	ext{ mm}$ geçme) ve dikmelerin hatasız güncellenmesi |
| 3 | `FAZ A.3 — Euler-Bernoulli Raf Sehim (Deflection) Kontrolü` | Faz A | **PASSED** | `2.66 ms` | $750	ext{ mm}$ açıklıkta güvenli sehim onayı; $1150	ext{ mm}$ açıklıklı $18	ext{ mm}$ rafta $L/300$ sehim aşım uyarısının tetiklenmesi |
| 4 | `FAZ B.1 — Kulp Görünürlüğü ve Doğru Kapak / Açılma Kenarı Konumu` | Faz B | **PASSED** | `5.06 ms` | Sol menteşeli kapakta kulpun sağ açılma kenarında, sağ menteşeli (`single_right`) kapakta kulpun sol açılma kenarında ve çekmecelerde merkezde görünmesi |
| 5 | `FAZ B.2 — Menteşeli, Sürgülü, Katlanır, Kalkar Kinematikleri ve Doğrulanmamış Sistem Engeli` | Faz B | **PASSED** | `6.14 ms` | Sürgülü kapakta X-öteleme, katlanır kapakta zıt açılı bi-fold rotasyon, kalkar kapakta üst eksen $-X$ rotasyonu ve doğrulanmamış `pocket` sistemde sahte hareketin engellenmesi (`isMechanismVerified: false`) |
| 6 | `FAZ C.1 — Çekmece Kasa Setback, Ray ve Raf/Kapak Ekleme-Silme-Konumlandırma` | Faz C | **PASSED** | `23.49 ms` | $1450	ext{ mm}$ kotuna özel raf ekleme/silme, çekmece kasasının çekmece önünü aşmaması ($20	ext{ mm}$ arka boşluk), üst kapağın çekmece grubunun üstünden başlaması ve BOM parça sayısının anlık güncellenmesi |
| 7 | `FAZ D.1 — 2D Planda Modül Taşıma ile 3D Konum Senkronizasyonu ve Manyetik Yapışma` | Faz D | **PASSED** | `2.46 ms` | 2D planda `(1018, 12)` noktasına sürüklenen modülün komşu modül kenarına (`x = 1000`) ve arka duvara (`z = 0`) manyetik yapışarak 3D konumunun güncellenmesi |
| 8 | `FAZ D.2 — Duvar, Pencere, Kapı Süpürme Alanı, Kolon ve Geçiş Koridoru Çakışma Testleri` | Faz D | **PASSED** | `2.14 ms` | `MODULE_COLLISION`, `OBSTACLE_COLLISION` (kolon), `WINDOW_OCCLUSION` (pencere denizlik kotu) ve `DOOR_SWING_COLLISION` (oda kapısı süpürme alanı) hatalarının yakalanması |
| 9 | `FAZ F.1 — BOM ile 3D Geometrinin Tek Kaynaktan Türetilmesi ve Kesim Ölçüsü Doğruluğu` | Faz F | **PASSED** | `3.69 ms` | Metal donanımların ahşap kesim listesine girmemesi, alt tablanın `1764 x 600 x 18 mm` (net kesim `1762 x 599 mm`) olarak doğru çıkması, sağ kapakta $35	ext{ mm}$ tas deliklerinin `width - 22.5` kenarında olması ve kulp/menteşe/ray adetlerinin doğrulanması |
| 10 | `FAZ F.2 — Üretim Kapısı (Fail-Closed ERP Gate)` | Faz F | **PASSED** | `4.35 ms` | $3100	ext{ mm}$ genişlikte standart ham plaka sınırını ($2780	ext{ mm}$) aşan parçada `isReadyForErp: false` ile ERP aktarımının engellenmesi |
| 11 | `FAZ E & V2 Regresyon — Proje Kaydetme/Yeniden Açma ve Tamamlayıcı V2 Modül Uyumluluğu` | Faz E / V2 | **PASSED** | `4.10 ms` | Versiyonlu JSON kaydetme/açma (`serializeProjectSnapshot` / `deserializeProjectSnapshot`) ve V2 tamamlayıcı tezgah (`complementaryRole: "countertop"`) modülünün geriye dönük uyumluluğu |

## 2. Gerçek TAP Test Çıktısı

```text
TAP version 13
ok 1 - FAZ A.1 — Kapalı Ölçü Zinciri (Dimension-Chain Closure): sum(bayWidths) + (N+1)*T === width
ok 2 - FAZ A.2 — Genişlik, Yükseklik ve Derinlik Değiştiğinde Tüm Bağımlı Parçaların Yeniden Hesaplanması
ok 3 - FAZ A.3 — Euler-Bernoulli Raf Sehim (Deflection) Kontrolü
ok 4 - FAZ B.1 — Kulp Görünürlüğü ve Doğru Kapak / Açılma Kenarı Konumlandırması
ok 5 - FAZ B.2 — Menteşeli, Sürgülü, Katlanır ve Kalkar Kapak Kinematikleri + Doğrulanmamış Sistem Engeli
ok 6 - FAZ C.1 — Çekmece Kasa Setback, Ray ve Raf/Kapak Ekleme-Silme-Konumlandırma
ok 7 - FAZ D.1 — 2D Planda Modül Taşıma/Döndürme ile 3D Konum Senkronizasyonu ve Manyetik Yapışma
ok 8 - FAZ D.2 — Duvar, Pencere, Kapı Süpürme Alanı, Kolon ve Geçiş Koridoru Çakışma Testleri
ok 9 - FAZ F.1 — BOM ile 3D Geometrinin Tek Kaynaktan Türetilmesi ve Panel Kesim Ölçüsü Doğruluğu
ok 10 - FAZ F.2 — Üretim Kapısı (Fail-Closed ERP Gate): Plaka Boyutu Aşımı veya Doğrulanmamış Mekanizmada ERP Engeli
ok 11 - FAZ E & V2 Regresyon — Proje Kaydetme/Yeniden Açma (Roundtrip) ve Tamamlayıcı V2 Modül Uyumluluğu
1..11
# tests 11
# pass 11
# fail 0
# duration_ms 747.360719
```

## 3. Doğrulanamayan İşlevler (`NOT VERIFIED`) ve Nedenleri

1. **Tam Next.js Production Build (`next build`) ve Playwright Tarayıcı E2E Render Testi (`NOT VERIFIED` in Sandbox VM)**:
   * Sandbox VM ortamında dış internet erişimi (`registry.npmjs.org`) güvenlik kısıtlamaları nedeniyle kapalı olduğundan Next.js 15 / Three.js `node_modules` paketleri VM içine indirilememiştir. Bu nedenle tüm parametrik geometri, kinematik, 2D/3D konum senkronizasyonu, çakışma ve BOM/CNC delik motorları Node.js üzerinde doğrudan çalıştırılarak doğrulanmış; tam tarayıcı WebGL render ve `next build` kontrolü `LOCAL_VERIFICATION.md` içindeki adımlarla yerel makinede çalıştırılmak üzere **`NOT VERIFIED (Local Execution Required)`** olarak raporlanmıştır.
2. **Pocket ve Tambour Kapak Mekanizmaları (`NOT VERIFIED`)**:
   * Fiziksel CNC kanal ve cep boşluğu parametreleri üretici kataloglarıyla doğrulanana kadar sistem içinde bilinçli olarak `isVerified: false` statüsünde kilitlenmiştir.
