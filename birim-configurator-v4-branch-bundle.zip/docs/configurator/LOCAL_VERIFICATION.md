# Yerel Kurulum, Dal Uygulama ve Doğrulama Kılavuzu (`LOCAL_VERIFICATION.md`)

Bu kılavuz, [Centan2025/birim-configurator](https://github.com/Centan2025/birim-configurator) deposunda `feat/configurator-parametric-engine-v4` dalını kendi bilgisayarınızda nasıl çalıştıracağınızı, birim ve E2E testlerini nasıl koşacağınızı ve `Studio`, `Plan (2D+3D)`, `Showroom` ve `V2` ekranlarında hangi senaryoları doğrulayacağınızı adım adım açıklar.

## 1. Hızlı Kurulum ve Geliştirme Dalına Geçiş

Eğer GitHub üzerinde `feat/configurator-parametric-engine-v4` dalı doğrudan push edilmişse:

```bash
git clone https://github.com/Centan2025/birim-configurator.git
cd birim-configurator
git fetch origin
git checkout feat/configurator-parametric-engine-v4
npm install
```

Eğer teslim edilen `birim-configurator-v4-branch-bundle.zip` paketini yerel deponuza uyguluyorsanız:

```bash
cd birim-configurator
unzip -o /path/to/birim-configurator-v4-branch-bundle.zip -d .
bash apply-v4-branch.sh
```

`apply-v4-branch.sh` betiği otomatik olarak `main` dalına dokunmadan `feat/configurator-parametric-engine-v4` dalını oluşturur, tüm Faz A–F dosyalarını ve `docs/configurator/*.md` belgelerini yerleştirir, testleri çalıştırır, değişiklikleri commit eder ve `origin/feat/configurator-parametric-engine-v4` dalına push eder.

## 2. Otomatik Test, Typecheck, Lint ve Build Kontrolleri

Proje kök dizininde sırasıyla şu komutları çalıştırın:

```bash
# 1. Bağımsız V4 Parametrik Motor Doğrulama Testleri (Node.js yerleşik test koşucusu)
node --test tests/v4-parametric-engine.test.mjs

# 2. Vitest Birim Test Süiti (Parametrik motor, BOM, kesim optimizasyonu, delik motoru)
npm test

# 3. TypeScript Tip Kontrolü ve Lint
npm run lint

# 4. Next.js Production Build Kontrolü
npm run build

# 5. Geliştirme Sunucusunu Başlatma (Port 3300)
npm run dev
```

Tarayıcınızda `http://localhost:3300` (V2 Ana Ekran) ve `http://localhost:3300/v3/studio` (V3.1 Studio) adreslerini açın.

## 3. Adım Adım Fonksiyonel Doğrulama Senaryoları ve Beklenen Sonuçlar

| Senaryo | Test Edilecek Ekran / Rota | Uygulama Adımları | Beklenen Doğru Sonuç |
| :--- | :--- | :--- | :--- |
| **Senaryo 1: Parametrik Ölçü ve Kapalı Ölçü Zinciri (Faz A)** | `/v3/studio` | 2 bölmeli gardırop modülü seçin. Genişliği `1800 mm`'den `2400 mm`'ye, yüksekliği `2200 mm`'den `2450 mm`'ye, derinliği `600 mm`'den `650 mm`'ye çıkarın. Ara dikme sayısını `2` yapın. | Sol/sağ yan paneller tam boy (`2450 mm`), alt/üst tabla `2364 mm`, kanallı arkalık `2380 x 2350 x 8 mm` olmalı; bölme genişlikleri toplamı + $4 	imes 18	ext{ mm}$ tam olarak `2400.00 mm` vermelidir. |
| **Senaryo 2: Kapak Kulpları ve Menteşe Yönleri (Faz B)** | `/v3/studio` | 1. bölmeyi `Sol Menteşeli (single_left)`, 2. bölmeyi `Sağ Menteşeli (single_right)` seçin ve kulp profili olarak `HRD_HANDLE_LONG_320` atayın. Kapak açılma sürgüsünü `0°` → `90°` hareket ettirin. | Her iki kapakta da kulp görünmeli; sol menteşeli kapağın kulpu sağ kenarda, sağ menteşeli kapağın kulpu sol kenarda durmalı ve kapak açılırken kulp kapak yüzeyiyle birlikte ayrılmadan dönmelidir. |
| **Senaryo 3: Sürgülü, Katlanır, Kalkar ve Doğrulanmamış Kapaklar (Faz B)** | `/v3/studio` | Kapak tipini sırasıyla `Sürgülü (sliding)`, `Katlanır (folding)`, `Kalkar (lift)` ve `Pocket (pocket)` olarak değiştirip açılma sürgüsünü test edin. | Sürgülü kapak X ekseninde kaymalı, katlanır kapak çift kanat olarak katlanmalı, kalkar kapak üst eksenden yukarı açılmalı; `Pocket` seçildiğinde ise `NOT VERIFIED` uyarısı görünmeli ve sahte açılma hareketi yapmamalıdır. |
| **Senaryo 4: İç Donanım Ekleme/Silme ve Çekmece-Kapak Uyumu (Faz C)** | `/v3/studio` | 1. bölmeye 2 adet çekmece (`200 mm`) ve 2 adet raf ekleyin. Raflardan birinin yüksekliğini `1450 mm` yapın, ardından çekmece açılma sürgüsünü `300 mm` çekin. | Çekmece kasası çekmece önünün iç yüzeyinden başlamalı (öne taşmamalı), üst kapak çekmece grubunun üstünden başlamalı ve raf silindiğinde hem 3D sahne hem BOM kesim listesi anında güncellenmelidir. |
| **Senaryo 5: 2D+3D Plan Senkronizasyonu ve Çakışma Doğrulaması (Faz D)** | `/v3/plan` | 2D planda bir modülü komşu modülün yanına ve arka duvara yaklaştırın. Ardından modülü bir kolonun (`column`), pencerenin (`window`) veya oda kapısı açılma alanının (`door`) üzerine sürükleyin. | Modül $35	ext{ mm}$ mesafede duvara ve komşu modüle manyetik yapışmalı, 3D görünümde aynı koordinata geçmeli; kolon/pencere/kapı üzerine geldiğinde kırmızı çakışma hatası üretmelidir. |
| **Senaryo 6: BOM, Kesim Listesi, CNC Delik ve ERP Kapısı (Faz F)** | `/v3/studio` & `BomModal` | BOM / Üretim Çıktısı modalını açın. Alt tabla, yan panel ve kapak ölçülerini, kenar bandı metrajını ve delik sayılarını inceleyin. | Metal donanımlar (kulp, ray, askı borusu) ahşap kesim listesinde (`cutPieces`) yer almamalı; alt tabla `1764 x 600 x 18 mm` (net kesim `1762 x 599 mm`), sağ kapak menteşe delikleri sağ kenarda (`width - 22.5 mm`) olmalı ve doğrulama hatası varken ERP aktarımı kilitlenmelidir. |
| **Senaryo 7: V2 Ana Ekran Regresyon Kontrolü** | `/` (Ana Rota) | `http://localhost:3300/` adresini açarak mevcut V2 konfigüratör işlevlerini kontrol edin. | Mevcut V2 ekranı hiçbir görsel veya işlevsel bozulma olmadan çalışmaya devam etmelidir. |
