# Birim V3.1 / V4 Parametrik Motor ve Sistem Mimarisi (`ARCHITECTURE.md`)

Bu belge, [Centan2025/birim-configurator](https://github.com/Centan2025/birim-configurator) deposunda `feat/configurator-parametric-engine-v4` dalı kapsamında uygulanan ortak parametrik geometri motorunu, veri modellerini, ölçü bağımlılık denklemlerini, kapak/kulp kinematiğini, 2D/3D Plan senkronizasyonunu ve BOM üretim kapısı mimarisini tanımlar.

## 1. Katmanlı Monorepo Mimarisi ve Tek Kaynaklı Doğruluk (Single Source of Truth)

Mevcut V2 ana ekranı (`apps/configurator/src/app/page.tsx`) tamamen korunurken, V3.1 çalışma modları (`Studio`, `Plan 2D+3D`, `Showroom`) ile üretim/BOM katmanı tek bir deterministik veri akışında birleştirilmiştir:

1. **`@birim/core` (`packages/core/src/types.ts`, `packages/core/src/rules.ts`)**:
   * Modül, gövde (`CarcassConfig`), bölme (`BayConfig`), kapak (`DoorConfig`), kulp, raf (`ShelfConfig`), çekmece (`DrawerConfig`), askı borusu (`HangingRailConfig`), iç aksesuar (`InternalAccessoryConfig`) ve mimari engel (`ArchitecturalElement`) veri modellerini barındırır.
   * Mekanizma doğrulama sicilini (`DOOR_MECHANISM_SPECS`), kapalı ölçü zinciri çözücüsünü (`calculateBayWidths`) ve Euler-Bernoulli raf sehim denetleyicisini (`calculateShelfDeflectionMm`) içerir.
2. **`@birim/geometry` (`packages/geometry/src/mesh-generator.ts`, `packages/geometry/src/types.ts`)**:
   * `generateModuleGeometry(module, options)` fonksiyonu üzerinden hem 3D sahnenin (`ThreeCanvas.tsx` ve `V3ThreeViewport.tsx`) hem 2D teknik görünüşlerin (`projection2d.ts`) hem de BOM motorunun kullandığı `ModuleGeometryBreakdown` çıktısını üretir.
   * Her bileşen (`ComponentGeometry`) hem 3D sınırlayıcı kutu (`dimensions`, `position`, `rotation`, `pivotPosition`) hem de net bitmiş panel kesim bilgisini (`cutDimensions: { finishedLengthMm, finishedWidthMm, thicknessMm, grain }`) ve `isPanelCutPiece` bayrağını taşır.
3. **`@birim/manufacturing` (`packages/manufacturing/src/bom-generator.ts`, `packages/manufacturing/src/drilling-engine.ts`)**:
   * `generateProjectBOM(project)` doğrudan `generateModuleGeometry(module)` çıktısını tüketir.
   * Metal donanım bileşenlerini (`isPanelCutPiece === false`) ahşap kesim listesinden (`cutPieces`) ayırır; kenar bandı kalınlıklarını (`1.0mm` gövde/raf, `2.0mm` kapak/çekmece önü) bitmiş ölçüden düşerek net testere kesim ölçülerini (`cutLengthMm`, `cutWidthMm`) hesaplar ve CNC delik koordinatlarını (`generateDrillingForComponent`) üretir.
4. **V3.1 Mekân ve İş Akışı Katmanı (`apps/configurator/src/v3/engine/kitchenSpatialEngine.ts`, `apps/configurator/src/v3/adapter/useV3Adapter.ts`)**:
   * 2D Plan ve 3D sahneyi aynı `DesignProject` durumu üzerinden senkronize eder (`moveModuleInPlan2D`).
   * Oda sınırları, modül-modül 3D AABB çakışmaları, kolon/radyatör engelleri, pencere denizlik kotu, oda kapısı açılma süpürme alanı (`swingRadiusMm`) ve $800	ext{ mm}$ minimum geçiş koridorunu (`frontClearanceBox`) doğrular.

## 2. Parametrik Geometri ve Ölçü Bağımlılık Denklemleri (Faz A)

Dış ölçüleri $W 	imes H 	imes D$ (genişlik, yükseklik, derinlik), gövde panel kalınlığı $T$, arkalık kalınlığı $T_{	ext{back}}$, baza yüksekliği $H_{	ext{plinth}}$ ve kapak derz boşluğu $g$ olan bir modül için tüm alt parçalar şu denklemlerle birbirine bağlıdır:

| Bileşen (`ComponentRole`) | Parça Kodu | Genişlik / Boy ($X$ veya Kesim Boyu) | Yükseklik / En ($Y$ veya Kesim Eni) | Derinlik / Kalınlık ($Z$) | 3D Konum ($x, y, z$) |
| :--- | :--- | :--- | :--- | :--- | :--- |
| Sol Yan Panel (`carcass_side_left`) | `A1` | $T$ | $H$ | $D$ | $(0, 0, 0)$ |
| Sağ Yan Panel (`carcass_side_right`) | `A2` | $T$ | $H$ | $D$ | $(W - T, 0, 0)$ |
| Alt Tabla (`carcass_bottom`) | `B1` | $W - 2T$ | $T$ | $D$ | $(T, H_{	ext{plinth}}, 0)$ |
| Üst Tabla (`carcass_top`) | `B2` | $W - 2T$ | $T$ | $D$ | $(T, H - T, 0)$ |
| Arkalık (`carcass_back`, kanallı $e_g = \min(8, 0.5T)$) | `C` | $(W - 2T) + 2e_g$ | $H_{	ext{net}} + 2e_g$ | $T_{	ext{back}}$ | $(T - e_g, H_{	ext{plinth}} + T - e_g, d_{	ext{groove}})$ |
| Ön Baza Klapası (`plinth`) | `D` | $W - 2T$ | $H_{	ext{plinth}}$ | $T$ | $(T, 0, D - T - 20)$ |
| Ara Dikme (`carcass_divider`, $i = 1 \dots N-1$) | `E_i` | $T$ | $H_{	ext{net}} = H - H_{	ext{plinth}} - 2T$ | $D_{	ext{net}} = D - d_{	ext{groove}} - T_{	ext{back}}$ | $(T + \sum_{k=0}^{i-1}(W_{	ext{bay},k} + T) - T, H_{	ext{plinth}} + T, d_{	ext{groove}} + T_{	ext{back}})$ |
| Sabit / Hareketli Raf (`shelf_fixed` / `shelf_adjustable`) | `F` | $W_{	ext{bay},b}$ | $T_{	ext{raf}}$ | $D_{	ext{net}} - d_{	ext{setback}}$ ($2	ext{ mm}$) | $(x_{	ext{bay},b}, y_{	ext{raf}}, d_{	ext{groove}} + T_{	ext{back}})$ |
| Çekmece Önü (`drawer_front`) | `DF` | $W_{	ext{bay},b} - 2g$ | $H_{	ext{drw},d}$ | $T$ | $(x_{	ext{bay},b} + g, y_{	ext{drw},d}, D + z_{	ext{open}})$ |
| Çekmece Yan Kasası (`drawer_side_left` / `right`) | `DSL`/`DSR` | $T_{	ext{box}} = 16	ext{ mm}$ | $\max(60, H_{	ext{drw},d} - 34)$ | $D_{	ext{box}} = D_{	ext{net}} - 20$ | $(x_{	ext{bay},b} + 10, y_{	ext{drw},d} + 12, D - D_{	ext{box}} + z_{	ext{open}})$ |

### Kapalı Ölçü Zinciri (Dimension-Chain Closure)
Bölme sayısı $N$ olan bir modülde, kilitli bölme genişlikleri (`customWidthMm`) korunduktan sonra kalan net iç genişlik kilitsiz bölmelere dağıtılır ve son bölmede yuvarlama farkı (`drift`) sıfırlanarak şu özdeşlik her zaman sağlanır:
$$\sum_{b=0}^{N-1} W_{	ext{bay},b} + (N + 1) \cdot T \equiv W$$

## 3. Kapak ve Kulp Kinematik Kuralları (Faz B)

* **Menteşe Yönü ve Kulp Eşleşmesi**:
  * Sol menteşeli kapaklarda (`single_left`, `inset_left`, çift kapağın sol kanadı) menteşe pivot ekseni sol kenarda ($x = x_{	ext{leaf}}$) yer alır, kapak $-Y$ yönünde ($0^\circ \dots 110^\circ$) açılır ve kulp (`door_handle`) sağ açılma kenarından $38	ext{ mm}$ içeride konumlanır.
  * Sağ menteşeli kapaklarda (`single_right`, `inset_right`, çift kapağın sağ kanadı) menteşe pivot ekseni sağ kenarda ($x = x_{	ext{leaf}} + W_{	ext{leaf}}$) yer alır, kapak $+Y$ yönünde açılır ve kulp sol açılma kenarından $38	ext{ mm}$ içeride konumlanır.
* **Mekanizma Bazlı Hareket Kuralları (`DOOR_MECHANISM_SPECS`)**:
  * `hinged_single`, `hinged_double`, `hinged_inset`, `hinged_overlay_variant`: Dikey menteşe ekseni etrafında $\pm 110^\circ$ Y-rotasyonu ve kulpun kapak açısıyla birlikte 3D yörünge dönüşümü.
  * `sliding_top_hung`, `sliding_bottom_rolling`: Çift raylı ($Z$ ekseninde $20	ext{–}22	ext{ mm}$ ray ofseti) 2 kanat üretim ve açılma oranına göre $\pm X$ ekseninde doğrusal öteleme.
  * `folding_side` (WingLine Bi-Fold): 2 kanadın zıt yönlü ($\mp 	heta$) katlanması ve ikinci kanadın menteşe kenarına doğru $X/Z$ düzleminde kinematik taşınması.
  * `lift_up_stay` (Aventos HK-S), `lift_parallel` (Aventos HL), `lift_bi_fold` (Aventos HF): Üst yatay eksende $-X$ rotasyonu veya paralel $Y/Z$ kalkış hareketi.
  * `pocket_retractable`, `tambour_roller`: Henüz gerçek CNC cep/kanal şablonu doğrulanmadığı için `isVerified: false` olarak işaretlenmiştir; 3D sahnede sahte açılma animasyonu yapmaz ve BOM üretim kapısında (`productionGate.isReadyForErp = false`) ERP aktarımını engeller.
