import { DesignProject, ModuleInstance, ArchitecturalElement, WallDefinition } from "@birim/core";

export interface OrientedFootprint2D {
  moduleId: string;
  moduleIndex: number;
  name: string;
  category: ModuleInstance["category"];
  x: number;
  z: number;
  planWidth: number;
  planDepth: number;
  yBottom: number;
  yTop: number;
  rotationY: number;
  rawWidth: number;
  rawHeight: number;
  rawDepth: number;
  frontClearanceBox: {
    x: number;
    z: number;
    width: number;
    depth: number;
  };
}

export interface SpatialValidationIssue {
  code: string;
  severity: "error" | "warning" | "info";
  message: string;
  affectedIds: string[];
}

export interface SpatialEngineeringValidationResult {
  isCompliant: boolean;
  footprints: OrientedFootprint2D[];
  issues: SpatialValidationIssue[];
  workTriangleMm?: number;
}

const MIN_PASSAGE_CLEARANCE_MM = 800; // Minimum ergonomic corridor / front passage clearance

export function getModuleOrientedFootprint(m: ModuleInstance, index: number): OrientedFootprint2D {
  const rot = ((m.rotationY || 0) % 360 + 360) % 360;
  const isSwapped = rot === 90 || rot === 270;
  const planWidth = isSwapped ? m.dimensions.depth : m.dimensions.width;
  const planDepth = isSwapped ? m.dimensions.width : m.dimensions.depth;

  // Front clearance zone (800mm in front of the module's opening direction)
  let frontX = m.position.x;
  let frontZ = m.position.z + planDepth;
  let frontW = planWidth;
  let frontD = MIN_PASSAGE_CLEARANCE_MM;

  if (rot === 90) {
    frontX = m.position.x + planWidth;
    frontZ = m.position.z;
    frontW = MIN_PASSAGE_CLEARANCE_MM;
    frontD = planDepth;
  } else if (rot === 180) {
    frontX = m.position.x;
    frontZ = m.position.z - MIN_PASSAGE_CLEARANCE_MM;
    frontW = planWidth;
    frontD = MIN_PASSAGE_CLEARANCE_MM;
  } else if (rot === 270) {
    frontX = m.position.x - MIN_PASSAGE_CLEARANCE_MM;
    frontZ = m.position.z;
    frontW = MIN_PASSAGE_CLEARANCE_MM;
    frontD = planDepth;
  }

  return {
    moduleId: m.id,
    moduleIndex: index,
    name: m.name,
    category: m.category,
    x: m.position.x,
    z: m.position.z,
    planWidth,
    planDepth,
    yBottom: m.position.y,
    yTop: m.position.y + m.dimensions.height,
    rotationY: rot,
    rawWidth: m.dimensions.width,
    rawHeight: m.dimensions.height,
    rawDepth: m.dimensions.depth,
    frontClearanceBox: { x: frontX, z: frontZ, width: frontW, depth: frontD },
  };
}

function boxesOverlap2D(
  a: { x: number; z: number; width: number; depth: number },
  b: { x: number; z: number; width: number; depth: number },
  toleranceMm = 1
): boolean {
  return (
    a.x + toleranceMm < b.x + b.width &&
    a.x + a.width - toleranceMm > b.x &&
    a.z + toleranceMm < b.z + b.depth &&
    a.z + a.depth - toleranceMm > b.z
  );
}

function rangesOverlap1D(aMin: number, aMax: number, bMin: number, bMax: number, tol = 1): boolean {
  return aMin + tol < bMax && aMax - tol > bMin;
}

/**
 * FAZ D: Synchronizes 2D Plan manipulation with 3D Module Position, including
 * magnetic wall/module snapping and room boundary clamping.
 */
export function moveModuleInPlan2D(
  project: DesignProject,
  moduleId: string,
  targetX: number,
  targetZ: number,
  options: { snapMm?: number; magneticSnapThresholdMm?: number } = {}
): DesignProject {
  const { snapMm = 10, magneticSnapThresholdMm = 35 } = options;
  const updatedModules = project.modules.map((m, idx) => {
    if (m.id !== moduleId) return m;
    const fp = getModuleOrientedFootprint(m, idx);

    let nextX = Math.round(targetX / snapMm) * snapMm;
    let nextZ = Math.round(targetZ / snapMm) * snapMm;

    // Wall snap (back wall z=0, left wall x=0, right wall x=room.width, front wall z=room.depth)
    if (Math.abs(nextX) <= magneticSnapThresholdMm) nextX = 0;
    if (Math.abs(nextZ) <= magneticSnapThresholdMm) nextZ = 0;
    if (Math.abs(nextX + fp.planWidth - project.room.width) <= magneticSnapThresholdMm) {
      nextX = project.room.width - fp.planWidth;
    }
    if (Math.abs(nextZ + fp.planDepth - project.room.depth) <= magneticSnapThresholdMm) {
      nextZ = project.room.depth - fp.planDepth;
    }

    // Magnetic edge snap to adjacent modules
    project.modules.forEach((other, oIdx) => {
      if (other.id === moduleId) return;
      const ofp = getModuleOrientedFootprint(other, oIdx);
      if (Math.abs(nextZ - ofp.z) <= magneticSnapThresholdMm) {
        nextZ = ofp.z;
      }
      if (Math.abs(nextX - (ofp.x + ofp.planWidth)) <= magneticSnapThresholdMm) {
        nextX = ofp.x + ofp.planWidth;
      } else if (Math.abs(nextX + fp.planWidth - ofp.x) <= magneticSnapThresholdMm) {
        nextX = ofp.x - fp.planWidth;
      }
    });

    return {
      ...m,
      position: {
        ...m.position,
        x: nextX,
        z: nextZ,
      },
    };
  });

  return {
    ...project,
    version: (project.version || 1) + 1,
    updatedAt: new Date().toISOString(),
    modules: updatedModules,
  };
}

/**
 * FAZ D: Validates 2D/3D room boundaries, module-to-module 3D AABB collisions,
 * architectural obstacles (walls, columns, windows, door swings), and passage clearances.
 */
export function validateSpatialAndKitchenEngineering(
  project: DesignProject
): SpatialEngineeringValidationResult {
  const footprints = project.modules.map((m, idx) => getModuleOrientedFootprint(m, idx));
  const issues: SpatialValidationIssue[] = [];
  const obstacles: ArchitecturalElement[] = project.room.obstacles || [];

  // 1. Room Boundary Validation (Duvar sınır kontrolü)
  footprints.forEach((fp) => {
    if (
      fp.x < 0 ||
      fp.z < 0 ||
      fp.x + fp.planWidth > project.room.width ||
      fp.z + fp.planDepth > project.room.depth ||
      fp.yTop > project.room.height
    ) {
      issues.push({
        code: "ROOM_BOUNDARY_OVERFLOW",
        severity: "error",
        message: `Modül "${fp.name}" oda/duvar sınırlarını (${project.room.width}x${project.room.depth}x${project.room.height}mm) aşıyor.`,
        affectedIds: [fp.moduleId],
      });
    }
  });

  // 2. Module-to-Module 3D AABB Collision Check
  for (let i = 0; i < footprints.length; i++) {
    for (let j = i + 1; j < footprints.length; j++) {
      const a = footprints[i];
      const b = footprints[j];
      const xyOverlap = rangesOverlap1D(a.yBottom, a.yTop, b.yBottom, b.yTop);
      const planOverlap = boxesOverlap2D(
        { x: a.x, z: a.z, width: a.planWidth, depth: a.planDepth },
        { x: b.x, z: b.z, width: b.planWidth, depth: b.planDepth }
      );
      if (xyOverlap && planOverlap) {
        issues.push({
          code: "MODULE_COLLISION",
          severity: "error",
          message: `"${a.name}" ile "${b.name}" modülleri 3D mekânda çakışıyor.`,
          affectedIds: [a.moduleId, b.moduleId],
        });
      }

      // Opposing module passage clearance check
      const clearanceOverlap = boxesOverlap2D(a.frontClearanceBox, {
        x: b.x,
        z: b.z,
        width: b.planWidth,
        depth: b.planDepth,
      });
      if (clearanceOverlap && xyOverlap && !planOverlap) {
        issues.push({
          code: "PASSAGE_CLEARANCE_VIOLATION",
          severity: "warning",
          message: `"${a.name}" ön geçiş ve kapak açılma alanı (${MIN_PASSAGE_CLEARANCE_MM}mm) "${b.name}" tarafından daraltılıyor.`,
          affectedIds: [a.moduleId, b.moduleId],
        });
      }
    }
  }

  // 3. Architectural Obstacles Validation (Column, Window, Door Swing, Radiator)
  footprints.forEach((fp) => {
    const modBox = { x: fp.x, z: fp.z, width: fp.planWidth, depth: fp.planDepth };
    obstacles.forEach((obs) => {
      const obsBox = { x: obs.x, z: obs.z, width: obs.width, depth: obs.depth };
      const yOverlap = rangesOverlap1D(fp.yBottom, fp.yTop, obs.y, obs.y + obs.height);

      if (obs.type === "column" || obs.type === "radiator") {
        if (boxesOverlap2D(modBox, obsBox) && yOverlap) {
          issues.push({
            code: "OBSTACLE_COLLISION",
            severity: "error",
            message: `Modül "${fp.name}", mimari eleman "${obs.label}" (${obs.type}) ile çakışıyor.`,
            affectedIds: [fp.moduleId, obs.id],
          });
        }
      } else if (obs.type === "window") {
        // Tall/wall modules blocking window light opening
        if (boxesOverlap2D(modBox, obsBox) && fp.yTop > obs.y) {
          issues.push({
            code: "WINDOW_OCCLUSION",
            severity: "error",
            message: `Modül "${fp.name}" üst kotu (${fp.yTop}mm), pencere "${obs.label}" denizlik kotunu (${obs.y}mm) kapatıyor.`,
            affectedIds: [fp.moduleId, obs.id],
          });
        }
      } else if (obs.type === "door") {
        const swingRadius = obs.swingRadiusMm || obs.width || 900;
        const doorSwingZone = {
          x: obs.x,
          z: obs.z,
          width: Math.max(obs.width, swingRadius),
          depth: Math.max(obs.depth, swingRadius),
        };
        if (boxesOverlap2D(modBox, doorSwingZone)) {
          issues.push({
            code: "DOOR_SWING_COLLISION",
            severity: "error",
            message: `Modül "${fp.name}", oda kapısı "${obs.label}" açılma süpürme alanını (${swingRadius}mm) engelliyor.`,
            affectedIds: [fp.moduleId, obs.id],
          });
        }
      }
    });
  });

  const hasErrors = issues.some((i) => i.severity === "error");
  return {
    isCompliant: !hasErrors,
    footprints,
    issues,
  };
}
