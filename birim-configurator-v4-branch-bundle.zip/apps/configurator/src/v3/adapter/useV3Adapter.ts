import {
  DesignProject,
  ModuleInstance,
  ShelfConfig,
  DrawerConfig,
  OpeningDirection,
  DoorSystemId,
  inferDoorSystemIdFromType,
} from "@birim/core";
import { generateModuleGeometry, ModuleGeometryBreakdown } from "@birim/geometry";
import { generateProjectBOM, ManufacturingBOM } from "@birim/manufacturing";
import {
  moveModuleInPlan2D,
  validateSpatialAndKitchenEngineering,
  SpatialEngineeringValidationResult,
} from "../engine/kitchenSpatialEngine";

export interface V3QuickUpdatePayload {
  width?: number;
  height?: number;
  depth?: number;
  bodyMaterialId?: string;
  doorMaterialId?: string;
  plinthHeight?: number;
  verticalDividerCount?: number;
}

/**
 * FAZ E: One-Click / Minimum-Click Parametric Module Mutations
 * Automatically synchronizes bays, dividers, doors, handles, 3D geometry, and BOM.
 */
export function updateModuleQuickParams(
  project: DesignProject,
  moduleId: string,
  patch: V3QuickUpdatePayload
): DesignProject {
  const modules = project.modules.map((mod) => {
    if (mod.id !== moduleId) return mod;

    const nextDimensions = {
      width: patch.width ?? mod.dimensions.width,
      height: patch.height ?? mod.dimensions.height,
      depth: patch.depth ?? mod.dimensions.depth,
    };

    const nextDividerCount =
      patch.verticalDividerCount !== undefined
        ? Math.max(0, patch.verticalDividerCount)
        : mod.carcass.verticalDividerCount;
    const targetBayCount = nextDividerCount + 1;

    const nextBays = [...mod.bays];
    while (nextBays.length < targetBayCount) {
      const idx = nextBays.length;
      nextBays.push({
        id: `${mod.id}_bay_${idx + 1}`,
        index: idx,
        shelves: [{ id: `${mod.id}_shelf_b${idx + 1}_1`, type: "adjustable" }],
        drawers: [],
        hangingRails: [],
        doors: mod.bays[0]?.doors ? { ...mod.bays[0].doors } : { type: "single_left", handleProfileId: "HRD_HANDLE_BAR_160" },
      });
    }
    if (nextBays.length > targetBayCount) {
      nextBays.length = targetBayCount;
    }

    return {
      ...mod,
      dimensions: nextDimensions,
      carcass: {
        ...mod.carcass,
        bodyMaterialId: patch.bodyMaterialId ?? mod.carcass.bodyMaterialId,
        doorMaterialId: patch.doorMaterialId ?? mod.carcass.doorMaterialId,
        plinthHeight: patch.plinthHeight ?? mod.carcass.plinthHeight,
        verticalDividerCount: nextDividerCount,
      },
      bays: nextBays,
    };
  });

  return {
    ...project,
    version: (project.version || 1) + 1,
    updatedAt: new Date().toISOString(),
    modules,
  };
}

export function setBayDoorAndHandle(
  project: DesignProject,
  moduleId: string,
  bayIndex: number,
  doorType: OpeningDirection,
  handleProfileId: string,
  systemId?: DoorSystemId
): DesignProject {
  const modules = project.modules.map((mod) => {
    if (mod.id !== moduleId) return mod;
    const bays = mod.bays.map((bay, idx) => {
      if (idx !== bayIndex) return bay;
      return {
        ...bay,
        doors: {
          ...bay.doors,
          type: doorType,
          systemId: systemId || inferDoorSystemIdFromType(doorType),
          handleProfileId,
        },
      };
    });
    return { ...mod, bays };
  });

  return {
    ...project,
    version: (project.version || 1) + 1,
    updatedAt: new Date().toISOString(),
    modules,
  };
}

export function addOrUpdateBayShelf(
  project: DesignProject,
  moduleId: string,
  bayIndex: number,
  shelf: ShelfConfig
): DesignProject {
  const modules = project.modules.map((mod) => {
    if (mod.id !== moduleId) return mod;
    const bays = mod.bays.map((bay, idx) => {
      if (idx !== bayIndex) return bay;
      const exists = bay.shelves.some((s) => s.id === shelf.id);
      const shelves = exists
        ? bay.shelves.map((s) => (s.id === shelf.id ? { ...s, ...shelf } : s))
        : [...bay.shelves, shelf];
      return { ...bay, shelves };
    });
    return { ...mod, bays };
  });

  return {
    ...project,
    version: (project.version || 1) + 1,
    updatedAt: new Date().toISOString(),
    modules,
  };
}

export function removeBayShelf(
  project: DesignProject,
  moduleId: string,
  bayIndex: number,
  shelfId: string
): DesignProject {
  const modules = project.modules.map((mod) => {
    if (mod.id !== moduleId) return mod;
    const bays = mod.bays.map((bay, idx) => {
      if (idx !== bayIndex) return bay;
      return { ...bay, shelves: bay.shelves.filter((s) => s.id !== shelfId) };
    });
    return { ...mod, bays };
  });

  return {
    ...project,
    version: (project.version || 1) + 1,
    updatedAt: new Date().toISOString(),
    modules,
  };
}

export function addOrUpdateBayDrawer(
  project: DesignProject,
  moduleId: string,
  bayIndex: number,
  drawer: DrawerConfig
): DesignProject {
  const modules = project.modules.map((mod) => {
    if (mod.id !== moduleId) return mod;
    const bays = mod.bays.map((bay, idx) => {
      if (idx !== bayIndex) return bay;
      const exists = bay.drawers.some((d) => d.id === drawer.id);
      const drawers = exists
        ? bay.drawers.map((d) => (d.id === drawer.id ? { ...d, ...drawer } : d))
        : [...bay.drawers, drawer];
      return { ...bay, drawers };
    });
    return { ...mod, bays };
  });

  return {
    ...project,
    version: (project.version || 1) + 1,
    updatedAt: new Date().toISOString(),
    modules,
  };
}

export function serializeProjectSnapshot(project: DesignProject): string {
  return JSON.stringify(
    {
      schemaVersion: "birim-v4.0",
      exportedAt: new Date().toISOString(),
      project,
    },
    null,
    2
  );
}

export function deserializeProjectSnapshot(rawJson: string): DesignProject {
  const parsed = JSON.parse(rawJson);
  const project: DesignProject = parsed.project ? parsed.project : parsed;
  if (!project || !project.id || !Array.isArray(project.modules) || !project.room) {
    throw new Error("Geçersiz proje dosyası: room veya modules alanı eksik.");
  }
  return project;
}

export function computeUnifiedWorkspaceState(
  project: DesignProject,
  options: { doorOpenAngleDeg?: number; drawerOpenMm?: number; explodedFactor?: number } = {}
): {
  geometries: Record<string, ModuleGeometryBreakdown>;
  spatial: SpatialEngineeringValidationResult;
  bom: ManufacturingBOM;
} {
  const geometries: Record<string, ModuleGeometryBreakdown> = {};
  project.modules.forEach((mod) => {
    geometries[mod.id] = generateModuleGeometry(mod, options);
  });
  const spatial = validateSpatialAndKitchenEngineering(project);
  const bom = generateProjectBOM(project);
  return { geometries, spatial, bom };
}

export { moveModuleInPlan2D };
