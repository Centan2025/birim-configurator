export type UnitLength = number; // in millimeters (mm)

export interface Dimensions3D {
  width: UnitLength;
  height: UnitLength;
  depth: UnitLength;
}

export interface Position3D {
  x: UnitLength;
  y: UnitLength;
  z: UnitLength;
}

export type OpeningDirection =
  | "left"
  | "right"
  | "double"
  | "lift"
  | "sliding"
  | "folding"
  | "open"
  | "none"
  | "single_left"
  | "single_right"
  | "inset_left"
  | "inset_right"
  | "inset_double"
  | "half_overlay_left"
  | "half_overlay_right"
  | "sliding_bottom"
  | "lift_parallel"
  | "lift_bi_fold"
  | "lift_up_stay"
  | "pocket"
  | "tambour";

export type DoorSystemId =
  | "hinged_single"
  | "hinged_double"
  | "hinged_inset"
  | "hinged_overlay_variant"
  | "sliding_top_hung"
  | "sliding_bottom_rolling"
  | "lift_parallel"
  | "lift_bi_fold"
  | "lift_up_stay"
  | "folding_side"
  | "pocket_retractable"
  | "tambour_roller"
  | "open";

export type DoorOverlayType = "full_overlay" | "half_overlay" | "inset";

export type HandleCategory =
  | "knob"
  | "bar_handle"
  | "long_profile_handle"
  | "edge_profile"
  | "recessed_grip"
  | "gola_profile"
  | "j_pull"
  | "milled_wood_grip"
  | "handleless_plain";

export typeHandlePlacement =
  | "auto"
  | "center"
  | "top_corner"
  | "bottom_corner"
  | "middle_edge"
  | "top_edge_horizontal";

export type GrainDirection = "vertical" | "horizontal" | "none";

export interface ShelfConfig {
  id: string;
  type: "fixed" | "adjustable";
  yPositionMm?: UnitLength; // Explicit height from carcass inner bottom (if repositioned)
  depthOffsetMm?: UnitLength; // Front setback (default 2mm for adjustable, 0mm for fixed)
  thicknessMm?: UnitLength;
}

export interface HangingRailConfig {
  id: string;
  yOffsetFromTopMm?: UnitLength; // Default 80mm below top panel
  profileType?: "oval_30x15" | "round_25" | "led_integrated";
}

export interface DrawerConfig {
  id: string;
  heightMm?: UnitLength; // Explicit front height (locked) or undefined for auto-distribution
  handleProfileId?: string;
  runnerSystemId?: string;
  softClose?: boolean;
}

export interface InternalAccessoryConfig {
  id: string;
  type: "trouser_rack" | "shoe_rack" | "jewelry_tray" | "pull_out_basket" | "led_strip";
  yPositionMm: UnitLength;
  heightMm: UnitLength;
}

export interface DoorConfig {
  type: OpeningDirection;
  systemId?: DoorSystemId;
  overlayType?: DoorOverlayType;
  handleProfileId?: string;
  handlePlacement?: "auto" | "center" | "top_corner" | "bottom_corner" | "middle_edge" | "top_edge_horizontal";
  softClose?: boolean;
}

export interface BayConfig {
  id: string;
  index: number;
  customWidthMm?: UnitLength; // Optional locked bay width; unlocked bays share remainder
  shelves: ShelfConfig[];
  drawers: DrawerConfig[];
  hangingRails: HangingRailConfig[];
  accessories?: InternalAccessoryConfig[];
  subDividers?: { id: string; xOffsetMm: UnitLength; startYMm: UnitLength; heightMm: UnitLength }[];
  doors?: DoorConfig;
}

export interface CarcassConfig {
  panelThickness: UnitLength; // Default 18mm
  backPanelThickness: UnitLength; // Default 8mm
  backMountType?: "grooved" | "rebated" | "applied"; // Default "grooved"
  backGrooveOffsetMm?: UnitLength; // Default 18mm from rear edge
  plinthHeight: UnitLength; // Default 80mm or 100mm
  bodyMaterialId: string;
  doorMaterialId?: string;
  doorPerimeterGap: UnitLength; // Default 2mm
  verticalDividerCount: number;
}

export interface ModuleInstance {
  id: string;
  name: string;
  code?: string;
  category: "wardrobe" | "base" | "wall" | "tall" | "corner" | "appliance" | "complementary";
  complementaryRole?: "countertop" | "waterfall_edge" | "plinth_strip" | "skirting" | "end_panel" | "wall_filler";
  dimensions: Dimensions3D;
  position: Position3D;
  rotationY?: number; // 0, 90, 180, 270 degrees
  carcass: CarcassConfig;
  bays: BayConfig[];
}

export interface WallDefinition {
  id: string;
  label: string;
  startX: UnitLength;
  startZ: UnitLength;
  endX: UnitLength;
  endZ: UnitLength;
  heightMm: UnitLength;
  thicknessMm: UnitLength;
}

export interface ArchitecturalElement {
  id: string;
  type: "door" | "window" | "column" | "radiator" | "niche";
  label: string;
  wallId?: string;
  x: UnitLength;
  y: UnitLength;
  z: UnitLength;
  width: UnitLength;
  height: UnitLength;
  depth: UnitLength;
  swingRadiusMm?: UnitLength; // For room doors: clearance arc radius
  clearanceFrontMm?: UnitLength; // Minimum required passage/front clearance
}

export interface DesignProject {
  id: string;
  name: string;
  version: number;
  updatedAt?: string;
  room: {
    width: UnitLength;
    height: UnitLength;
    depth: UnitLength;
    walls?: WallDefinition[];
    obstacles?: ArchitecturalElement[];
  };
  modules: ModuleInstance[];
}
