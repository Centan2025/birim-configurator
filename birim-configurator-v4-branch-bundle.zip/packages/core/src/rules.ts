import {
  ModuleInstance,
  DoorSystemId,
  OpeningDirection,
  UnitLength,
} from "./types";

export interface MechanismKinematicSpec {
  systemId: DoorSystemId;
  label: string;
  isVerified: boolean;
  kinematicType: "hinged_pivot" | "sliding_track" | "bi_fold" | "lift_stay" | "lift_parallel" | "lift_bifold" | "open_none" | "unverified";
  maxAngleDeg: number;
  leafCountPerBay: 1 | 2;
  trackOffsetZMm: number;
  requiresTopClearanceMm: number;
  reasonIfUnverified?: string;
}

export const DOOR_MECHANISM_SPECS: Record<DoorSystemId, MechanismKinematicSpec> = {
  hinged_single: {
    systemId: "hinged_single",
    label: "Tek Kanat Menteşeli (Blum Clip Top 110°)",
    isVerified: true,
    kinematicType: "hinged_pivot",
    maxAngleDeg: 110,
    leafCountPerBay: 1,
    trackOffsetZMm: 0,
    requiresTopClearanceMm: 0,
  },
  hinged_double: {
    systemId: "hinged_double",
    label: "Çift Kanat Menteşeli (Blum Clip Top 110°)",
    isVerified: true,
    kinematicType: "hinged_pivot",
    maxAngleDeg: 110,
    leafCountPerBay: 2,
    trackOffsetZMm: 0,
    requiresTopClearanceMm: 0,
  },
  hinged_inset: {
    systemId: "hinged_inset",
    label: "İçerlek (Inset) Menteşeli Kapak",
    isVerified: true,
    kinematicType: "hinged_pivot",
    maxAngleDeg: 110,
    leafCountPerBay: 1,
    trackOffsetZMm: -18,
    requiresTopClearanceMm: 0,
  },
  hinged_overlay_variant: {
    systemId: "hinged_overlay_variant",
    label: "Yarım Binili (Half-Overlay) Menteşeli Kapak",
    isVerified: true,
    kinematicType: "hinged_pivot",
    maxAngleDeg: 110,
    leafCountPerBay: 1,
    trackOffsetZMm: 0,
    requiresTopClearanceMm: 0,
  },
  sliding_top_hung: {
    systemId: "sliding_top_hung",
    label: "Üstten Askılı Sürgülü Sistem (Çift Ray)",
    isVerified: true,
    kinematicType: "sliding_track",
    maxAngleDeg: 0,
    leafCountPerBay: 2,
    trackOffsetZMm: 22,
    requiresTopClearanceMm: 0,
  },
  sliding_bottom_rolling: {
    systemId: "sliding_bottom_rolling",
    label: "Alttan Taşıyıcılı Sürgülü Sistem",
    isVerified: true,
    kinematicType: "sliding_track",
    maxAngleDeg: 0,
    leafCountPerBay: 2,
    trackOffsetZMm: 20,
    requiresTopClearanceMm: 0,
  },
  folding_side: {
    systemId: "folding_side",
    label: "Katlanır (Bi-Fold) Kapak Mekanizması (WingLine)",
    isVerified: true,
    kinematicType: "bi_fold",
    maxAngleDeg: 90,
    leafCountPerBay: 2,
    trackOffsetZMm: 0,
    requiresTopClearanceMm: 0,
  },
  lift_up_stay: {
    systemId: "lift_up_stay",
    label: "Tek Parça Kalkar Kapak (Blum Aventos HK-S / HK top)",
    isVerified: true,
    kinematicType: "lift_stay",
    maxAngleDeg: 107,
    leafCountPerBay: 1,
    trackOffsetZMm: 0,
    requiresTopClearanceMm: 120,
  },
  lift_parallel: {
    systemId: "lift_parallel",
    label: "Paralel Kalkar Kapak (Blum Aventos HL)",
    isVerified: true,
    kinematicType: "lift_parallel",
    maxAngleDeg: 0,
    leafCountPerBay: 1,
    trackOffsetZMm: 180,
    requiresTopClearanceMm: 350,
  },
  lift_bi_fold: {
    systemId: "lift_bi_fold",
    label: "Katlanır Kalkar Kapak (Blum Aventos HF)",
    isVerified: true,
    kinematicType: "lift_bifold",
    maxAngleDeg: 95,
    leafCountPerBay: 2,
    trackOffsetZMm: 0,
    requiresTopClearanceMm: 180,
  },
  pocket_retractable: {
    systemId: "pocket_retractable",
    label: "Gövde İçi Gizlenir (Pocket) Kapak Sistemi",
    isVerified: false,
    kinematicType: "unverified",
    maxAngleDeg: 0,
    leafCountPerBay: 1,
    trackOffsetZMm: 0,
    requiresTopClearanceMm: 0,
    reasonIfUnverified:
      "Pocket (gövde içi gizlenir) mekanizmanın iç yan panel cep boşluğu ve CNC delik şablonu henüz üretim onayı almamıştır (NOT VERIFIED).",
  },
  tambour_roller: {
    systemId: "tambour_roller",
    label: "Panjur (Tambour) Kapak Sistemi",
    isVerified: false,
    kinematicType: "unverified",
    maxAngleDeg: 0,
    leafCountPerBay: 1,
    trackOffsetZMm: 0,
    requiresTopClearanceMm: 0,
    reasonIfUnverified:
      "Tambour (panjur) salyangoz kanal profili ve lamel sarım hacmi henüz CNC üretim onayı almamıştır (NOT VERIFIED).",
  },
  open: {
    systemId: "open",
    label: "Kapaksız Açık Modül",
    isVerified: true,
    kinematicType: "open_none",
    maxAngleDeg: 0,
    leafCountPerBay: 1,
    trackOffsetZMm: 0,
    requiresTopClearanceMm: 0,
  },
};

export function inferDoorSystemIdFromType(type: OpeningDirection): DoorSystemId {
  switch (type) {
    case "left":
    case "single_left":
    case "right":
    case "single_right":
      return "hinged_single";
    case "double":
      return "hinged_double";
    case "inset_left":
    case "inset_right":
    case "inset_double":
      return "hinged_inset";
    case "half_overlay_left":
    case "half_overlay_right":
      return "hinged_overlay_variant";
    case "sliding":
      return "sliding_top_hung";
    case "sliding_bottom":
      return "sliding_bottom_rolling";
    case "folding":
      return "folding_side";
    case "lift":
    case "lift_up_stay":
      return "lift_up_stay";
    case "lift_parallel":
      return "lift_parallel";
    case "lift_bi_fold":
      return "lift_bi_fold";
    case "pocket":
      return "pocket_retractable";
    case "tambour":
      return "tambour_roller";
    default:
      return "open";
  }
}

/**
 * FAZ A: Exact Dimension-Chain Closure for Bay Widths
 * Guarantees sum(bayWidths) + (bayCount + 1) * T === module.dimensions.width
 * with zero floating-point drift. Supports locked customWidthMm per bay.
 */
export function calculateBayWidths(module: ModuleInstance): UnitLength[] {
  const T = module.carcass.panelThickness;
  const bayCount = Math.max(1, module.bays.length || module.carcass.verticalDividerCount + 1);
  const totalDividerAndSideThickness = (bayCount + 1) * T;
  const totalAvailableInnerWidth = Math.max(bayCount * 100, module.dimensions.width - totalDividerAndSideThickness);

  let lockedSum = 0;
  let unlockedIndices: number[] = [];

  for (let i = 0; i < bayCount; i++) {
    const bay = module.bays[i];
    if (bay && typeof bay.customWidthMm === "number" && bay.customWidthMm >= 100) {
      lockedSum += bay.customWidthMm;
    } else {
      unlockedIndices.push(i);
    }
  }

  // Auto-fix if locked bays exceed total available inner width
  if (lockedSum > totalAvailableInnerWidth - unlockedIndices.length * 100) {
    unlockedIndices = Array.from({ length: bayCount }, (_, idx) => idx);
    lockedSum = 0;
  }

  const remainingWidth = totalAvailableInnerWidth - lockedSum;
  const widths: number[] = new Array(bayCount).fill(0);

  if (unlockedIndices.length > 0) {
    const baseUnlockedW = Math.floor((remainingWidth / unlockedIndices.length) * 100) / 100;
    let distributed = 0;
    unlockedIndices.forEach((idx, pos) => {
      if (pos === unlockedIndices.length - 1) {
        widths[idx] = Number((remainingWidth - distributed).toFixed(2));
      } else {
        widths[idx] = baseUnlockedW;
        distributed += baseUnlockedW;
      }
    });
  }

  for (let i = 0; i < bayCount; i++) {
    const bay = module.bays[i];
    if (bay && typeof bay.customWidthMm === "number" && bay.customWidthMm >= 100 && lockedSum > 0) {
      widths[i] = bay.customWidthMm;
    }
  }

  // Final closure guarantee on last bay
  const currentSum = widths.reduce((a, b) => a + b, 0);
  const drift = Number((totalAvailableInnerWidth - currentSum).toFixed(2));
  if (Math.abs(drift) > 0 && widths.length > 0) {
    widths[widths.length - 1] = Number((widths[widths.length - 1] + drift).toFixed(2));
  }

  return widths;
}

export function calculateNetInnerHeight(module: ModuleInstance): UnitLength {
  const T = module.carcass.panelThickness;
  const plinth = Math.max(0, module.carcass.plinthHeight || 0);
  return Math.max(100, module.dimensions.height - plinth - 2 * T);
}

export function calculateNetInnerDepth(module: ModuleInstance): UnitLength {
  const T_back = module.carcass.backPanelThickness || 8;
  const mountType = module.carcass.backMountType || "grooved";
  const grooveOffset =
    mountType === "grooved"
      ? (module.carcass.backGrooveOffsetMm ?? 18)
      : 0;
  return Math.max(100, module.dimensions.depth - grooveOffset - T_back);
}

/**
 * Calculates grooved back panel engagement depth into side/top/bottom panels:
 * e_g = min(8mm, 0.5 * T)
 */
export function calculateBackPanelEngagementMm(panelThickness: UnitLength, mountType = "grooved"): UnitLength {
  if (mountType === "applied") return 0;
  return Math.min(8, Math.floor(panelThickness * 0.5));
}

/**
 * Euler-Bernoulli Shelf Deflection Check (inspired by Cabineteer / OpenCabinet I7 rule)
 * Returns deflection in mm under uniform load (default 40 kg/m = 0.392 N/mm)
 */
export function calculateShelfDeflectionMm(
  spanMm: UnitLength,
  depthMm: UnitLength,
  thicknessMm: UnitLength,
  elasticModulusMpa = 2500, // Standard particleboard / MDF E ≈ 2500 N/mm²
  uniformLoadNPerMm = 0.392
): { deflectionMm: number; limitMm: number; exceedsLimit: boolean } {
  const I = (depthMm * Math.pow(thicknessMm, 3)) / 12; // mm^4
  const deflectionMm =
    I > 0 ? (5 * uniformLoadNPerMm * Math.pow(spanMm, 4)) / (384 * elasticModulusMpa * I) : 0;
  const limitMm = spanMm / 300; // Industry standard L/300 sag limit
  return {
    deflectionMm: Number(deflectionMm.toFixed(3)),
    limitMm: Number(limitMm.toFixed(3)),
    exceedsLimit: deflectionMm > limitMm || spanMm > 900,
  };
}
