import {
  DesignProject,
  DOOR_MECHANISM_SPECS,
  inferDoorSystemIdFromType,
} from "@birim/core";
import { generateModuleGeometry, ComponentGeometry } from "@birim/geometry";
import { generateDrillingForComponent, DrillingHole } from "./drilling-engine";

export interface EdgeBandingConfig {
  top: boolean;
  bottom: boolean;
  left: boolean;
  right: boolean;
  thicknessMm: number;
}

export interface CutPiece {
  id: string;
  partCode: string;
  moduleId: string;
  label: string;
  role: string;
  materialId: string;
  thicknessMm: number;
  finishedLengthMm: number;
  finishedWidthMm: number;
  cutLengthMm: number; // Deducting edgebanding thickness on left/right edges
  cutWidthMm: number;  // Deducting edgebanding thickness on top/bottom edges
  quantity: number;
  areaM2: number;
  edgebandLinearMeters: number;
  edgeBanding: EdgeBandingConfig;
  drillingHoles: DrillingHole[];
}

export interface HardwareBOMItem {
  id: string;
  name: string;
  quantity: number;
  unit: "pcs" | "set" | "pair" | "m";
  unitPrice: number;
  totalPrice: number;
}

export interface ProductionReadinessReport {
  isReadyForErp: boolean;
  blockingErrors: string[];
  warnings: string[];
}

export interface ManufacturingBOM {
  projectId: string;
  generatedAt: string;
  totalCutPiecesCount: number;
  totalHardwareCount: number;
  totalPanelAreaM2: number;
  totalEdgebandMeters: number;
  cutPieces: CutPiece[];
  hardwareItems: HardwareBOMItem[];
  productionGate: ProductionReadinessReport;
}

const STANDARD_SHEET_LENGTH_MM = 2800;
const STANDARD_SHEET_WIDTH_MM = 2070;
const SHEET_TRIM_MM = 10;

export function resolveEdgeBandingForRole(role: string): EdgeBandingConfig {
  if (role === "door_leaf" || role === "drawer_front") {
    return { top: true, bottom: true, left: true, right: true, thicknessMm: 2.0 };
  }
  if (
    role === "carcass_side_left" ||
    role === "carcass_side_right" ||
    role === "carcass_bottom" ||
    role === "carcass_top" ||
    role === "carcass_divider" ||
    role === "carcass_sub_divider" ||
    role === "plinth"
  ) {
    return { top: true, bottom: false, left: true, right: true, thicknessMm: 1.0 };
  }
  if (role === "shelf_fixed" || role === "shelf_adjustable") {
    return { top: true, bottom: false, left: false, right: false, thicknessMm: 1.0 };
  }
  if (role === "drawer_side_left" || role === "drawer_side_right" || role === "drawer_back") {
    return { top: true, bottom: false, left: false, right: false, thicknessMm: 0.8 };
  }
  return { top: false, bottom: false, left: false, right: false, thicknessMm: 0 };
}

/**
 * Extracts true panel finished dimensions (length, width, thickness) from 3D ComponentGeometry.
 * Fixes the critical V3.1 bug where horizontal/frontal panels used min(height, depth) = 18mm as width!
 */
export function extractPanelDimensions(comp: ComponentGeometry): {
  finishedLengthMm: number;
  finishedWidthMm: number;
  thicknessMm: number;
} {
  if (comp.cutDimensions) {
    return {
      finishedLengthMm: comp.cutDimensions.finishedLengthMm,
      finishedWidthMm: comp.cutDimensions.finishedWidthMm,
      thicknessMm: comp.cutDimensions.thicknessMm,
    };
  }
  const sorted = [comp.dimensions.width, comp.dimensions.height, comp.dimensions.depth].sort(
    (a, b) => b - a
  );
  return {
    finishedLengthMm: sorted[0],
    finishedWidthMm: sorted[1],
    thicknessMm: sorted[2],
  };
}

export function generateProjectBOM(project: DesignProject): ManufacturingBOM {
  const cutPieces: CutPiece[] = [];
  const hardwareMap = new Map<string, HardwareBOMItem>();
  const blockingErrors: string[] = [];
  const warnings: string[] = [];

  const maxAllowedLength = STANDARD_SHEET_LENGTH_MM - 2 * SHEET_TRIM_MM;
  const maxAllowedWidth = STANDARD_SHEET_WIDTH_MM - 2 * SHEET_TRIM_MM;

  project.modules.forEach((mod) => {
    const geom = generateModuleGeometry(mod);
    warnings.push(...geom.warnings);

    // 1. Only panel cut pieces go into cutPieces (exclude metal handles, rails, slides!)
    const panelComponents = geom.components.filter((c) => c.isPanelCutPiece !== false);

    panelComponents.forEach((comp, idx) => {
      const { finishedLengthMm, finishedWidthMm, thicknessMm } = extractPanelDimensions(comp);
      const edgeBanding = resolveEdgeBandingForRole(comp.role);
      const ebT = edgeBanding.thicknessMm;

      const deductLength = (edgeBanding.left ? ebT : 0) + (edgeBanding.right ? ebT : 0);
      const deductWidth = (edgeBanding.top ? ebT : 0) + (edgeBanding.bottom ? ebT : 0);

      const cutLengthMm = Number(Math.max(10, finishedLengthMm - deductLength).toFixed(2));
      const cutWidthMm = Number(Math.max(10, finishedWidthMm - deductWidth).toFixed(2));
      const areaM2 = Number(((finishedLengthMm * finishedWidthMm) / 1_000_000).toFixed(4));

      const edgeMeters =
        ((edgeBanding.top ? finishedLengthMm : 0) +
          (edgeBanding.bottom ? finishedLengthMm : 0) +
          (edgeBanding.left ? finishedWidthMm : 0) +
          (edgeBanding.right ? finishedWidthMm : 0)) /
        1000;

      // Oversize stock sheet verification gate
      if (cutLengthMm > maxAllowedLength || cutWidthMm > maxAllowedWidth) {
        blockingErrors.push(
          `Modül ${mod.name} (${comp.label}): Net kesim ölçüsü (${cutLengthMm}x${cutWidthMm}mm) standart ham plaka sınırını (${maxAllowedLength}x${maxAllowedWidth}mm) aşıyor.`
        );
      }

      const holes = generateDrillingForComponent(comp);

      cutPieces.push({
        id: comp.id,
        partCode: comp.partCode || `P${idx + 1}`,
        moduleId: mod.id,
        label: comp.label,
        role: comp.role,
        materialId: comp.materialId,
        thicknessMm,
        finishedLengthMm,
        finishedWidthMm,
        cutLengthMm,
        cutWidthMm,
        quantity: 1,
        areaM2,
        edgebandLinearMeters: Number(edgeMeters.toFixed(3)),
        edgeBanding,
        drillingHoles: holes,
      });
    });

    // 2. Structural Carcass Connectors (Minifix + Dowels for Top, Bottom, Dividers, Fixed Shelves)
    const fixedJointPanelCount =
      2 + // Top + Bottom
      Math.max(0, geom.bayWidths.length - 1) + // Vertical dividers
      mod.bays.reduce((sum, b) => sum + b.shelves.filter((s) => s.type === "fixed").length, 0);
    addHardwareItem(
      hardwareMap,
      "HRD_MINIFIX_SET",
      "Minifix Gövde Bağlantı Seti (Eksantrik + Mil + Kavela)",
      fixedJointPanelCount * 4,
      "set",
      0.85
    );

    // 3. Hardware per Bay (Hinges, Mechanisms, Door Handles, Drawer Slides, Drawer Handles, Shelf Pins, Hanging Rails)
    mod.bays.forEach((bay, bayIdx) => {
      // Adjustable shelf pins (4 per adjustable shelf)
      const adjShelfCount = bay.shelves.filter((s) => s.type !== "fixed").length;
      if (adjShelfCount > 0) {
        addHardwareItem(
          hardwareMap,
          "HRD_SHELF_PIN_5MM",
          "Çelik Raf Pimi Ø5mm",
          adjShelfCount * 4,
          "pcs",
          0.25
        );
      }

      // Hanging rails & flange brackets
      bay.hangingRails.forEach((rail) => {
        addHardwareItem(
          hardwareMap,
          rail.profileType || "HRD_HANGING_RAIL_OVAL",
          "Oval Gardırop Askı Borusu + Flanş Takımı",
          1,
          "set",
          14.5
        );
      });

      // Internal accessories
      if (bay.accessories) {
        bay.accessories.forEach((acc) => {
          addHardwareItem(
            hardwareMap,
            `HRD_ACC_${acc.type.toUpperCase()}`,
            `İç Donanım Aksesuarı (${acc.type})`,
            1,
            "set",
            45.0
          );
        });
      }

      // Drawers (Runners + Handles)
      bay.drawers.forEach((drw) => {
        const runnerLength = Math.min(550, Math.max(250, Math.floor(( geom.netInnerDepth - 20) / 50) * 50));
        addHardwareItem(
          hardwareMap,
          drw.runnerSystemId || `HRD_RUNNER_${runnerLength}`,
          `Blum Tandem Tam Açılım Frenli Ray ${runnerLength}mm`,
          1,
          "pair",
          22.0
        );
        if (drw.handleProfileId && drw.handleProfileId !== "handleless_plain") {
          addHardwareItem(
            hardwareMap,
            drw.handleProfileId,
            `Kulp (${drw.handleProfileId})`,
            1,
            "pcs",
            8.5
          );
        }
      });

      // Doors (Mechanism Hardware + Door Handles)
      if (bay.doors && bay.doors.type !== "none" && bay.doors.type !== "open") {
        const systemId = bay.doors.systemId || inferDoorSystemIdFromType(bay.doors.type);
        const spec = DOOR_MECHANISM_SPECS[systemId];

        if (!spec.isVerified) {
          blockingErrors.push(
            `Modül ${mod.name} Bölme ${bayIdx + 1}: Seçilen kapak mekanizması (${spec.label}) henüz doğrulanmamıştır (${spec.reasonIfUnverified}). Üretim emri oluşturulamaz.`
          );
        }

        const isDouble =
          bay.doors.type === "double" ||
          bay.doors.type === "inset_double" ||
          spec.leafCountPerBay === 2;
        const doorLeafCount = isDouble ? 2 : 1;

        if (spec.kinematicType === "hinged_pivot") {
          const hingesPerLeaf =
            mod.dimensions.height > 1600 ? 4 : mod.dimensions.height > 950 ? 3 : 2;
          addHardwareItem(
            hardwareMap,
            "HRD_HINGE_CLIPTOP_110",
            "Blum Clip Top Blumotion 110° Frenli Menteşe + Taban",
            doorLeafCount * hingesPerLeaf,
            "pcs",
            4.8
          );
        } else if (spec.kinematicType === "sliding_track") {
          addHardwareItem(
            hardwareMap,
            `HRD_SLIDING_${systemId.toUpperCase()}`,
            `${spec.label} Ray ve Tekerlek Seti`,
            1,
            "set",
            95.0
          );
        } else if (spec.kinematicType === "bi_fold") {
          addHardwareItem(
            hardwareMap,
            "HRD_FOLDING_WINGLINE",
            "Katlanır Kapak Mekanizma Seti (WingLine)",
            1,
            "set",
            78.0
          );
        } else if (
          spec.kinematicType === "lift_stay" ||
          spec.kinematicType === "lift_parallel" ||
          spec.kinematicType === "lift_bifold"
        ) {
          addHardwareItem(
            hardwareMap,
            `HRD_LIFT_${systemId.toUpperCase()}`,
            `${spec.label} Kalkar Kapak Güç Ünitesi Seti`,
            1,
            "set",
            85.0
          );
        }

        // Door Handles (FAZ B & F: Ensures every door handle in 3D is also counted in BOM!)
        const handleProfileId = bay.doors.handleProfileId || "HRD_HANDLE_BAR_160";
        if (handleProfileId !== "handleless_plain" && handleProfileId !== "none") {
          const handleCount = spec.kinematicType === "lift_bifold" ? 1 : doorLeafCount;
          addHardwareItem(
            hardwareMap,
            handleProfileId,
            `Kulp (${handleProfileId})`,
            handleCount,
            "pcs",
            8.5
          );
        }
      }
    });
  });

  const hardwareItems = Array.from(hardwareMap.values());
  const totalPanelAreaM2 = Number(
    cutPieces.reduce((sum, p) => sum + p.areaM2 * p.quantity, 0).toFixed(4)
  );
  const totalEdgebandMeters = Number(
    cutPieces.reduce((sum, p) => sum + p.edgebandLinearMeters * p.quantity, 0).toFixed(3)
  );

  return {
    projectId: project.id,
    generatedAt: new Date().toISOString(),
    totalCutPiecesCount: cutPieces.length,
    totalHardwareCount: hardwareItems.reduce((sum, h) => sum + h.quantity, 0),
    totalPanelAreaM2,
    totalEdgebandMeters,
    cutPieces,
    hardwareItems,
    productionGate: {
      isReadyForErp: blockingErrors.length === 0,
      blockingErrors,
      warnings,
    },
  };
}

function addHardwareItem(
  map: Map<string, HardwareBOMItem>,
  id: string,
  name: string,
  qty: number,
  unit: "pcs" | "set" | "pair" | "m",
  unitPrice: number
) {
  const existing = map.get(id);
  if (existing) {
    existing.quantity += qty;
    existing.totalPrice = Number((existing.quantity * existing.unitPrice).toFixed(2));
  } else {
    map.set(id, {
      id,
      name,
      quantity: qty,
      unit,
      unitPrice,
      totalPrice: Number((qty * unitPrice).toFixed(2)),
    });
  }
}
