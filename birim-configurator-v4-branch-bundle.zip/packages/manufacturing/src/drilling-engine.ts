import { ComponentGeometry } from "@birim/geometry";

export interface DrillingHole {
  id: string;
  diameter: number;
  depth: number;
  x: number;
  y: number;
  z: number;
  direction: "face_front" | "face_back" | "edge_left" | "edge_right" | "edge_top" | "edge_bottom";
  purpose: "minifix_bolt" | "minifix_cam" | "dowel" | "shelf_support" | "hinge_cup" | "screw_pilot" | "handle_bolt";
}

export function generateDrillingForComponent(comp: ComponentGeometry): DrillingHole[] {
  const holes: DrillingHole[] = [];
  const { width, height, depth } = comp.dimensions;

  // 1. Carcass Side Panels & Vertical Dividers (X is thickness T=18mm, Y is height, Z is depth)
  if (
    comp.role === "carcass_side_left" ||
    comp.role === "carcass_side_right" ||
    comp.role === "carcass_divider"
  ) {
    const panelSpanZ = depth; // True horizontal width of the side panel
    const panelHeightY = height;
    const T = width;

    // Minifix bolt & dowel holes along Z span (at 50mm from front and 50mm from back)
    const jointZPositions = [50, Math.max(96, panelSpanZ - 50)];
    jointZPositions.forEach((zPos, idx) => {
      holes.push({
        id: `H_${comp.id}_minifix_bolt_bot_${idx}`,
        diameter: 8,
        depth: 12,
        x: zPos,
        y: T / 2,
        z: 0,
        direction: "face_front",
        purpose: "minifix_bolt",
      });
      holes.push({
        id: `H_${comp.id}_dowel_bot_${idx}`,
        diameter: 8,
        depth: 12,
        x: zPos + 32,
        y: T / 2,
        z: 0,
        direction: "face_front",
        purpose: "dowel",
      });
      holes.push({
        id: `H_${comp.id}_minifix_bolt_top_${idx}`,
        diameter: 8,
        depth: 12,
        x: zPos,
        y: panelHeightY - T / 2,
        z: 0,
        direction: "face_front",
        purpose: "minifix_bolt",
      });
      holes.push({
        id: `H_${comp.id}_dowel_top_${idx}`,
        diameter: 8,
        depth: 12,
        x: zPos + 32,
        y: panelHeightY - T / 2,
        z: 0,
        direction: "face_front",
        purpose: "dowel",
      });
    });

    // System 32 shelf support pin holes (Blum 37mm front setback + rear row, 32mm vertical pitch)
    const startY = 128;
    const endY = panelHeightY - 128;
    const pinZFront = 37;
    const pinZBack = Math.max(100, panelSpanZ - 64);

    let holeIdx = 0;
    for (let y = startY; y <= endY; y += 32) {
      holes.push({
        id: `H_${comp.id}_shelf_pin_f_${holeIdx}`,
        diameter: 5,
        depth: 12,
        x: pinZFront,
        y,
        z: 0,
        direction: "face_front",
        purpose: "shelf_support",
      });
      holes.push({
        id: `H_${comp.id}_shelf_pin_b_${holeIdx}`,
        diameter: 5,
        depth: 12,
        x: pinZBack,
        y,
        z: 0,
        direction: "face_front",
        purpose: "shelf_support",
      });
      holeIdx++;
    }
  }

  // 2. Door Leaves (35mm Hinge Cups on Hinge Edge + Handle Through-Holes on Opening Edge)
  if (comp.role === "door_leaf") {
    const doorW = width;
    const doorH = height;
    const hingeSide = comp.doorHingeSide || "left";

    if (hingeSide === "left" || hingeSide === "right") {
      const hingeX = hingeSide === "right" ? doorW - 22.5 : 22.5;
      const screwOffsetX = hingeSide === "right" ? hingeX + 9.5 : hingeX - 9.5;
      const hingePositionsY =
        doorH > 1600
          ? [100, Math.round(doorH * 0.36), Math.round(doorH * 0.64), doorH - 100]
          : doorH > 950
          ? [100, Math.round(doorH / 2), doorH - 100]
          : [100, doorH - 100];

      hingePositionsY.forEach((yPos, idx) => {
        holes.push({
          id: `H_${comp.id}_hinge_cup_${idx}`,
          diameter: 35,
          depth: 13.5,
          x: hingeX,
          y: yPos,
          z: 0,
          direction: "face_back",
          purpose: "hinge_cup",
        });
        holes.push({
          id: `H_${comp.id}_hinge_screw_1_${idx}`,
          diameter: 2.5,
          depth: 10,
          x: screwOffsetX,
          y: yPos - 22.5,
          z: 0,
          direction: "face_back",
          purpose: "screw_pilot",
        });
        holes.push({
          id: `H_${comp.id}_hinge_screw_2_${idx}`,
          diameter: 2.5,
          depth: 10,
          x: screwOffsetX,
          y: yPos + 22.5,
          z: 0,
          direction: "face_back",
          purpose: "screw_pilot",
        });
      });
    }
  }

  // 3. Top & Bottom Panels (Minifix Cam 15mm + Edge Dowel 8mm along depth Z)
  if (comp.role === "carcass_bottom" || comp.role === "carcass_top") {
    const panelW = width;
    const panelD = depth;
    const jointZPositions = [50, Math.max(96, panelD - 50)];

    jointZPositions.forEach((zPos, idx) => {
      holes.push({
        id: `H_${comp.id}_minifix_cam_l_${idx}`,
        diameter: 15,
        depth: 14,
        x: 34,
        y: zPos,
        z: 0,
        direction: "face_back",
        purpose: "minifix_cam",
      });
      holes.push({
        id: `H_${comp.id}_edge_dowel_l_${idx}`,
        diameter: 8,
        depth: 25,
        x: 0,
        y: zPos + 32,
        z: 9,
        direction: "edge_left",
        purpose: "dowel",
      });
      holes.push({
        id: `H_${comp.id}_minifix_cam_r_${idx}`,
        diameter: 15,
        depth: 14,
        x: panelW - 34,
        y: zPos,
        z: 0,
        direction: "face_back",
        purpose: "minifix_cam",
      });
      holes.push({
        id: `H_${comp.id}_edge_dowel_r_${idx}`,
        diameter: 8,
        depth: 25,
        x: panelW,
        y: zPos + 32,
        z: 9,
        direction: "edge_right",
        purpose: "dowel",
      });
    });
  }

  return holes;
}
