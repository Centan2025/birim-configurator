import { UnitLength, Position3D, Dimensions3D, DoorSystemId, GrainDirection } from "@birim/core";

export type ComponentRole =
  | "carcass_side_left"
  | "carcass_side_right"
  | "carcass_bottom"
  | "carcass_top"
  | "carcass_divider"
  | "carcass_sub_divider"
  | "carcass_back"
  | "plinth"
  | "shelf_fixed"
  | "shelf_adjustable"
  | "hanging_rail"
  | "drawer_front"
  | "drawer_side_left"
  | "drawer_side_right"
  | "drawer_back"
  | "drawer_bottom"
  | "drawer_handle"
  | "drawer_slide"
  | "door_leaf"
  | "door_handle"
  | "hinge_hardware"
  | "accessory_unit"
  | "countertop";

export interface ComponentGeometry {
  id: string;
  partCode?: string; // Universal part code (A, B, C...) shared across 3D, 2D, and BOM
  role: ComponentRole;
  label: string;
  bayIndex?: number;
  dimensions: Dimensions3D; // 3D bounding box dimensions (width: dx, height: dy, depth: dz)
  cutDimensions?: {
    finishedLengthMm: UnitLength;
    finishedWidthMm: UnitLength;
    thicknessMm: UnitLength;
    grain: GrainDirection;
  };
  position: Position3D; // Local position relative to module origin (bottom-left-rear = 0,0,0)
  pivotPosition?: Position3D; // Hinge or mechanism pivot origin in module space
  rotation?: [number, number, number]; // Euler angles [rx, ry, rz] in radians
  materialId: string;
  isFrontFacing?: boolean;
  isPanelCutPiece?: boolean; // True for wooden board cutlist items, false for metal hardware
  doorSystemId?: DoorSystemId;
  doorHingeSide?: "left" | "right" | "top" | "sliding_front" | "sliding_rear" | "none";
  parentComponentId?: string; // Links door_handle to door_leaf or drawer_handle to drawer_front
  hardwareRefId?: string;
  isMechanismVerified?: boolean;
}

export interface ModuleGeometryBreakdown {
  moduleId: string;
  overall: Dimensions3D;
  components: ComponentGeometry[];
  bayWidths: UnitLength[];
  netInnerHeight: UnitLength;
  netInnerDepth: UnitLength;
  warnings: string[];
}
