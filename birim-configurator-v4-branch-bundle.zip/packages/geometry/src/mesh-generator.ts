import {
  ModuleInstance,
  calculateBayWidths,
  calculateNetInnerHeight,
  calculateNetInnerDepth,
  calculateBackPanelEngagementMm,
  calculateShelfDeflectionMm,
  inferDoorSystemIdFromType,
  DOOR_MECHANISM_SPECS,
} from "@birim/core";
import { ComponentGeometry, ModuleGeometryBreakdown } from "./types";

export interface GenerateGeometryOptions {
  doorOpenAngleDeg?: number; // 0 = closed, up to mechanism maxAngleDeg
  drawerOpenMm?: number; // 0 = closed, up to slide stroke
  explodedFactor?: number; // 0 = normal, 1 = fully exploded
}

const SHELF_FRONT_SETBACK_MM = 2; // 2mm front setback for adjustable shelves (Cabinet Studio standard)
const DRAWER_REAR_CLEARANCE_MM = 20; // 20mm rear clearance from back panel inside face
const UNDERMOUNT_RUNNER_GAP_MM = 10; // 10mm per side for undermount runner clearance

export function generateModuleGeometry(
  module: ModuleInstance,
  options: GenerateGeometryOptions = {}
): ModuleGeometryBreakdown {
  const { doorOpenAngleDeg = 0, drawerOpenMm = 0, explodedFactor = 0 } = options;
  const { width, height, depth } = module.dimensions;
  const {
    panelThickness: T,
    backPanelThickness: T_back,
    plinthHeight,
    bodyMaterialId,
    doorMaterialId,
    doorPerimeterGap,
  } = module.carcass;
  const mountType = module.carcass.backMountType || "grooved";
  const backGrooveOffset =
    mountType === "grooved" ? (module.carcass.backGrooveOffsetMm ?? 18) : 0;
  const backEngagement = calculateBackPanelEngagementMm(T, mountType);

  const warnings: string[] = [];

  if (module.category === "complementary" && module.complementaryRole) {
    const compRole =
      module.complementaryRole === "countertop" || module.complementaryRole === "waterfall_edge"
        ? "countertop"
        : module.complementaryRole === "plinth_strip" || module.complementaryRole === "skirting"
        ? "plinth"
        : "carcass_side_left";
    return {
      moduleId: module.id,
      overall: module.dimensions,
      components: [
        {
          id: `${module.id}_comp_main`,
          partCode: "A",
          role: compRole,
          label: module.name,
          dimensions: { width, height, depth },
          cutDimensions: {
            finishedLengthMm: Math.max(width, depth),
            finishedWidthMm: Math.min(width, depth),
            thicknessMm: height <= 40 ? height : T,
            grain: "horizontal",
          },
          position: { x: 0, y: 0, z: 0 },
          materialId: bodyMaterialId,
          isFrontFacing: true,
          isPanelCutPiece: true,
        },
      ],
      bayWidths: [width],
      netInnerHeight: height,
      netInnerDepth: depth,
      warnings,
    };
  }

  const components: ComponentGeometry[] = [];
  const bayWidths = calculateBayWidths(module);
  const netInnerH = calculateNetInnerHeight(module);
  const netInnerD = calculateNetInnerDepth(module);

  const explodeX = explodedFactor * 80;
  const explodeY = explodedFactor * 80;
  const explodeZ = explodedFactor * 80;

  // --- 1. Left Side Panel (Full height to floor) ---
  components.push({
    id: `${module.id}_side_left`,
    partCode: "A1",
    role: "carcass_side_left",
    label: "Sol Yan Panel",
    dimensions: { width: T, height, depth },
    cutDimensions: {
      finishedLengthMm: height,
      finishedWidthMm: depth,
      thicknessMm: T,
      grain: "vertical",
    },
    position: { x: -explodeX, y: 0, z: 0 },
    materialId: bodyMaterialId,
    isPanelCutPiece: true,
  });

  // --- 2. Right Side Panel (Full height to floor) ---
  components.push({
    id: `${module.id}_side_right`,
    partCode: "A2",
    role: "carcass_side_right",
    label: "Sağ Yan Panel",
    dimensions: { width: T, height, depth },
    cutDimensions: {
      finishedLengthMm: height,
      finishedWidthMm: depth,
      thicknessMm: T,
      grain: "vertical",
    },
    position: { x: width - T + explodeX, y: 0, z: 0 },
    materialId: bodyMaterialId,
    isPanelCutPiece: true,
  });

  // --- 3. Bottom Panel (Taban Tablası - inset between side panels above plinth) ---
  const horizPanelW = width - 2 * T;
  components.push({
    id: `${module.id}_bottom`,
    partCode: "B1",
    role: "carcass_bottom",
    label: "Alt Tabla",
    dimensions: { width: horizPanelW, height: T, depth },
    cutDimensions: {
      finishedLengthMm: horizPanelW,
      finishedWidthMm: depth,
      thicknessMm: T,
      grain: "horizontal",
    },
    position: { x: T, y: plinthHeight - explodeY, z: 0 },
    materialId: bodyMaterialId,
    isPanelCutPiece: true,
  });

  // --- 4. Top Panel (Üst Tabla - inset between side panels) ---
  components.push({
    id: `${module.id}_top`,
    partCode: "B2",
    role: "carcass_top",
    label: "Üst Tabla",
    dimensions: { width: horizPanelW, height: T, depth },
    cutDimensions: {
      finishedLengthMm: horizPanelW,
      finishedWidthMm: depth,
      thicknessMm: T,
      grain: "horizontal",
    },
    position: { x: T, y: height - T + explodeY, z: 0 },
    materialId: bodyMaterialId,
    isPanelCutPiece: true,
  });

  // --- 5. Back Panel (Arkalık - with grooved engagement e_g = min(8mm, 0.5*T)) ---
  const backW = horizPanelW + 2 * backEngagement;
  const backH = netInnerH + 2 * backEngagement;
  components.push({
    id: `${module.id}_back`,
    partCode: "C",
    role: "carcass_back",
    label: "Arkalık Paneli",
    dimensions: { width: backW, height: backH, depth: T_back },
    cutDimensions: {
      finishedLengthMm: Math.max(backW, backH),
      finishedWidthMm: Math.min(backW, backH),
      thicknessMm: T_back,
      grain: "vertical",
    },
    position: {
      x: T - backEngagement,
      y: plinthHeight + T - backEngagement,
      z: backGrooveOffset - explodeZ,
    },
    materialId: bodyMaterialId,
    isPanelCutPiece: true,
  });

  // --- 6. Plinth (Baza Klapası) ---
  if (plinthHeight > 0) {
    components.push({
      id: `${module.id}_plinth`,
      partCode: "D",
      role: "plinth",
      label: "Ön Baza Klapası",
      dimensions: { width: horizPanelW, height: plinthHeight, depth: T },
      cutDimensions: {
        finishedLengthMm: horizPanelW,
        finishedWidthMm: plinthHeight,
        thicknessMm: T,
        grain: "horizontal",
      },
      position: { x: T, y: -explodeY, z: depth - T - 20 },
      materialId: bodyMaterialId,
      isPanelCutPiece: true,
    });
  }

  // --- 7. Vertical Dividers (Ara Dikmeler) ---
  let currentX = T;
  const dividerCount = Math.max(0, bayWidths.length - 1);
  for (let i = 0; i < dividerCount; i++) {
    currentX += bayWidths[i];
    components.push({
      id: `${module.id}_divider_${i + 1}`,
      partCode: `E${i + 1}`,
      role: "carcass_divider",
      label: `Ara Dikme ${i + 1}`,
      dimensions: { width: T, height: netInnerH, depth: netInnerD },
      cutDimensions: {
        finishedLengthMm: netInnerH,
        finishedWidthMm: netInnerD,
        thicknessMm: T,
        grain: "vertical",
      },
      position: { x: currentX, y: plinthHeight + T, z: backGrooveOffset + T_back },
      materialId: bodyMaterialId,
      isPanelCutPiece: true,
    });
    currentX += T;
  }

  // --- 8. Internal Elements & Fronts per Bay (FAZ A, B, C) ---
  let bayStartX = T;
  module.bays.forEach((bay, bayIdx) => {
    const bayW = bayWidths[bayIdx] ?? bayWidths[0];
    const innerZ0 = backGrooveOffset + T_back;
    const innerY0 = plinthHeight + T;

    // Calculate drawer stack height first so shelves & doors know the remaining upper opening
    const drawerCount = bay.drawers.length;
    let totalDrawerZoneHeightMm = 0;
    const resolvedDrawerHeights: number[] = [];

    if (drawerCount > 0) {
      // Determine if drawers occupy full bay or bottom stack
      const hasUpperElements =
        bay.shelves.length > 0 ||
        bay.hangingRails.length > 0 ||
        (bay.doors && bay.doors.type !== "none" && bay.doors.type !== "open");

      const defaultTargetZoneH = hasUpperElements
        ? Math.min(netInnerH * 0.45, drawerCount * 200)
        : netInnerH;

      let lockedDrawerSum = 0;
      let unlockedCount = 0;
      bay.drawers.forEach((drw) => {
        if (typeof drw.heightMm === "number" && drw.heightMm >= 80) {
          lockedDrawerSum += drw.heightMm;
        } else {
          unlockedCount++;
        }
      });

      const totalGaps = (drawerCount + 1) * doorPerimeterGap;
      const availableForUnlocked = Math.max(
        unlockedCount * 100,
        defaultTargetZoneH - totalGaps - lockedDrawerSum
      );
      const autoDrawerH =
        unlockedCount > 0 ? Number((availableForUnlocked / unlockedCount).toFixed(2)) : 0;

      bay.drawers.forEach((drw) => {
        const h =
          typeof drw.heightMm === "number" && drw.heightMm >= 80 ? drw.heightMm : autoDrawerH;
        resolvedDrawerHeights.push(h);
      });

      totalDrawerZoneHeightMm =
        resolvedDrawerHeights.reduce((a, b) => a + b, 0) + drawerCount * doorPerimeterGap;
    }

    const upperZoneStartY = innerY0 + totalDrawerZoneHeightMm;
    const upperZoneHeight = Math.max(100, netInnerH - totalDrawerZoneHeightMm);

    // --- 8A. Shelves (with deflection check & explicit yPositionMm support) ---
    bay.shelves.forEach((shelf, sIdx) => {
      const shelfT = shelf.thicknessMm || T;
      const setback =
        shelf.depthOffsetMm !== undefined
          ? shelf.depthOffsetMm
          : shelf.type === "adjustable"
          ? SHELF_FRONT_SETBACK_MM
          : 0;
      const shelfDepth = Math.max(100, netInnerD - setback);

      // Deflection check
      const deflection = calculateShelfDeflectionMm(bayW, shelfDepth, shelfT);
      if (deflection.exceedsLimit) {
        warnings.push(
          `Bölme ${bayIdx + 1} Raf ${sIdx + 1}: Açıklık ${bayW}mm için hesaplanan sehim (${deflection.deflectionMm}mm) sınır değeri (${deflection.limitMm}mm) aşıyor. Ara dikme veya 25mm raf önerilir.`
        );
      }

      const defaultY =
        upperZoneStartY + ((sIdx + 1) * upperZoneHeight) / (bay.shelves.length + 1);
      const resolvedY =
        typeof shelf.yPositionMm === "number"
          ? Math.min(innerY0 + netInnerH - shelfT - 50, Math.max(innerY0 + 50, innerY0 + shelf.yPositionMm))
          : Number(defaultY.toFixed(2));

      components.push({
        id: shelf.id || `${module.id}_shelf_b${bayIdx + 1}_${sIdx + 1}`,
        partCode: `F${bayIdx + 1}_${sIdx + 1}`,
        role: shelf.type === "fixed" ? "shelf_fixed" : "shelf_adjustable",
        label: `${shelf.type === "fixed" ? "Sabit" : "Hareketli"} Raf B${bayIdx + 1}-${sIdx + 1}`,
        bayIndex: bayIdx,
        dimensions: { width: bayW, height: shelfT, depth: shelfDepth },
        cutDimensions: {
          finishedLengthMm: bayW,
          finishedWidthMm: shelfDepth,
          thicknessMm: shelfT,
          grain: "horizontal",
        },
        position: { x: bayStartX, y: resolvedY, z: innerZ0 },
        materialId: bodyMaterialId,
        isPanelCutPiece: true,
      });
    });

    // --- 8B. Hanging Rails (Askı Borusu) ---
    bay.hangingRails.forEach((rail, rIdx) => {
      const yOffset = rail.yOffsetFromTopMm ?? 80 + rIdx * 900;
      const railY = Math.max(upperZoneStartY + 100, height - T - yOffset);
      components.push({
        id: rail.id || `${module.id}_rail_b${bayIdx + 1}_${rIdx + 1}`,
        role: "hanging_rail",
        label: `Askı Borusu B${bayIdx + 1}-${rIdx + 1}`,
        bayIndex: bayIdx,
        dimensions: { width: bayW, height: 30, depth: 15 },
        position: { x: bayStartX, y: railY, z: innerZ0 + netInnerD / 2 },
        materialId: "mat_anodized_metal",
        isPanelCutPiece: false,
        hardwareRefId: "HRD_HANGING_RAIL_OVAL",
      });
    });

    // --- 8C. Internal Accessories (Trouser rack, shoe rack, pull-out basket, etc.) ---
    if (bay.accessories && bay.accessories.length > 0) {
      bay.accessories.forEach((acc, aIdx) => {
        components.push({
          id: acc.id || `${module.id}_acc_b${bayIdx + 1}_${aIdx + 1}`,
          role: "accessory_unit",
          label: `İç Aksesuar (${acc.type}) B${bayIdx + 1}-${aIdx + 1}`,
          bayIndex: bayIdx,
          dimensions: { width: bayW - 20, height: acc.heightMm || 80, depth: netInnerD - 30 },
          position: { x: bayStartX + 10, y: innerY0 + acc.yPositionMm, z: innerZ0 + 15 },
          materialId: "mat_anodized_metal",
          isPanelCutPiece: false,
          hardwareRefId: `HRD_ACC_${acc.type.toUpperCase()}`,
        });
      });
    }

    // --- 8D. Sub-Dividers (Bölme İçi Ara Dikme) ---
    if (bay.subDividers && bay.subDividers.length > 0) {
      bay.subDividers.forEach((sub, sdIdx) => {
        components.push({
          id: sub.id || `${module.id}_subdiv_b${bayIdx + 1}_${sdIdx + 1}`,
          partCode: `SD${bayIdx + 1}_${sdIdx + 1}`,
          role: "carcass_sub_divider",
          label: `İç Ara Dikme B${bayIdx + 1}-${sdIdx + 1}`,
          bayIndex: bayIdx,
          dimensions: { width: T, height: sub.heightMm, depth: netInnerD - 5 },
          cutDimensions: {
            finishedLengthMm: sub.heightMm,
            finishedWidthMm: netInnerD - 5,
            thicknessMm: T,
            grain: "vertical",
          },
          position: {
            x: bayStartX + Math.min(bayW - T, Math.max(50, sub.xOffsetMm)),
            y: innerY0 + sub.startYMm,
            z: innerZ0,
          },
          materialId: bodyMaterialId,
          isPanelCutPiece: true,
        });
      });
    }

    // --- 8E. Drawers & Undermount Slides ---
    let currentDrawerY = innerY0 + doorPerimeterGap;
    bay.drawers.forEach((drawer, dIdx) => {
      const frontH = resolvedDrawerHeights[dIdx];
      const frontW = Number((bayW - 2 * doorPerimeterGap).toFixed(2));
      const boxD = Math.max(250, netInnerD - DRAWER_REAR_CLEARANCE_MM);
      const maxStroke = Math.min(450, Math.round(boxD * 0.85));
      const pulledZ = Math.min(maxStroke, Math.max(0, drawerOpenMm));
      const frontId = `${drawer.id}_front`;

      // 1. Drawer Front Panel
      components.push({
        id: frontId,
        partCode: `DF${bayIdx + 1}_${dIdx + 1}`,
        role: "drawer_front",
        label: `Çekmece Önü B${bayIdx + 1}-${dIdx + 1}`,
        bayIndex: bayIdx,
        dimensions: { width: frontW, height: frontH, depth: T },
        cutDimensions: {
          finishedLengthMm: frontW,
          finishedWidthMm: frontH,
          thicknessMm: T,
          grain: "horizontal",
        },
        position: { x: bayStartX + doorPerimeterGap, y: currentDrawerY, z: depth + pulledZ },
        materialId: doorMaterialId || bodyMaterialId,
        isFrontFacing: true,
        isPanelCutPiece: true,
      });

      // 2. Drawer Handle (Child of Drawer Front)
      if (drawer.handleProfileId && drawer.handleProfileId !== "handleless_plain") {
        const handleW = Math.min(160, Math.max(64, frontW - 60));
        components.push({
          id: `${drawer.id}_handle`,
          role: "drawer_handle",
          label: `Çekmece Kulpu B${bayIdx + 1}-${dIdx + 1}`,
          bayIndex: bayIdx,
          parentComponentId: frontId,
          hardwareRefId: drawer.handleProfileId,
          dimensions: { width: handleW, height: 14, depth: 24 },
          position: {
            x: bayStartX + doorPerimeterGap + (frontW - handleW) / 2,
            y: currentDrawerY + frontH - Math.min(35, frontH / 2),
            z: depth + T + pulledZ + explodeZ,
          },
          materialId: "mat_anodized_metal",
          isFrontFacing: true,
          isPanelCutPiece: false,
        });
      }

      // 3. Drawer Box (Sides, Back, Bottom) — Strictly behind drawer front (z <= depth)
      const boxT = 16;
      const boxH = Math.max(60, frontH - 34);
      const boxX0 = bayStartX + UNDERMOUNT_RUNNER_GAP_MM;
      const boxW = bayW - 2 * UNDERMOUNT_RUNNER_GAP_MM;
      const boxZ0 = depth - boxD + pulledZ; // Box front meets inside face of drawer_front at z = depth

      components.push({
        id: `${drawer.id}_side_left`,
        partCode: `DSL${bayIdx + 1}_${dIdx + 1}`,
        role: "drawer_side_left",
        label: `Çekmece Sol Yan B${bayIdx + 1}-${dIdx + 1}`,
        bayIndex: bayIdx,
        dimensions: { width: boxT, height: boxH, depth: boxD },
        cutDimensions: {
          finishedLengthMm: boxD,
          finishedWidthMm: boxH,
          thicknessMm: boxT,
          grain: "horizontal",
        },
        position: { x: boxX0, y: currentDrawerY + 12, z: boxZ0 },
        materialId: bodyMaterialId,
        isPanelCutPiece: true,
      });

      components.push({
        id: `${drawer.id}_side_right`,
        partCode: `DSR${bayIdx + 1}_${dIdx + 1}`,
        role: "drawer_side_right",
        label: `Çekmece Sağ Yan B${bayIdx + 1}-${dIdx + 1}`,
        bayIndex: bayIdx,
        dimensions: { width: boxT, height: boxH, depth: boxD },
        cutDimensions: {
          finishedLengthMm: boxD,
          finishedWidthMm: boxH,
          thicknessMm: boxT,
          grain: "horizontal",
        },
        position: { x: boxX0 + boxW - boxT, y: currentDrawerY + 12, z: boxZ0 },
        materialId: bodyMaterialId,
        isPanelCutPiece: true,
      });

      const innerBoxW = boxW - 2 * boxT;
      components.push({
        id: `${drawer.id}_back`,
        partCode: `DBK${bayIdx + 1}_${dIdx + 1}`,
        role: "drawer_back",
        label: `Çekmece Arkalığı B${bayIdx + 1}-${dIdx + 1}`,
        bayIndex: bayIdx,
        dimensions: { width: innerBoxW, height: boxH - 12, depth: boxT },
        cutDimensions: {
          finishedLengthMm: innerBoxW,
          finishedWidthMm: boxH - 12,
          thicknessMm: boxT,
          grain: "horizontal",
        },
        position: { x: boxX0 + boxT, y: currentDrawerY + 12 + T_back, z: boxZ0 },
        materialId: bodyMaterialId,
        isPanelCutPiece: true,
      });

      components.push({
        id: `${drawer.id}_bottom`,
        partCode: `DBM${bayIdx + 1}_${dIdx + 1}`,
        role: "drawer_bottom",
        label: `Çekmece Tabanı B${bayIdx + 1}-${dIdx + 1}`,
        bayIndex: bayIdx,
        dimensions: { width: innerBoxW + 12, height: T_back, depth: boxD },
        cutDimensions: {
          finishedLengthMm: boxD,
          finishedWidthMm: innerBoxW + 12,
          thicknessMm: T_back,
          grain: "horizontal",
        },
        position: { x: boxX0 + boxT - 6, y: currentDrawerY + 12, z: boxZ0 },
        materialId: bodyMaterialId,
        isPanelCutPiece: true,
      });

      // 4. Undermount Slides (Left & Right)
      components.push({
        id: `${drawer.id}_slide_left`,
        role: "drawer_slide",
        label: `Gizli Ray Sol B${bayIdx + 1}-${dIdx + 1}`,
        bayIndex: bayIdx,
        dimensions: { width: 10, height: 18, depth: boxD },
        position: { x: bayStartX, y: currentDrawerY + 4, z: depth - boxD + pulledZ * 0.5 },
        materialId: "mat_anodized_metal",
        isPanelCutPiece: false,
        hardwareRefId: drawer.runnerSystemId || `HRD_RUNNER_${boxD}`,
      });

      components.push({
        id: `${drawer.id}_slide_right`,
        role: "drawer_slide",
        label: `Gizli Ray Sağ B${bayIdx + 1}-${dIdx + 1}`,
        bayIndex: bayIdx,
        dimensions: { width: 10, height: 18, depth: boxD },
        position: { x: bayStartX + bayW - 10, y: currentDrawerY + 4, z: depth - boxD + pulledZ * 0.5 },
        materialId: "mat_anodized_metal",
        isPanelCutPiece: false,
        hardwareRefId: drawer.runnerSystemId || `HRD_RUNNER_${boxD}`,
      });

      currentDrawerY += frontH + doorPerimeterGap;
    });

    // --- 8F. Doors, Mechanism Kinematics & Handle Placement (FAZ B) ---
    if (bay.doors && bay.doors.type !== "none" && bay.doors.type !== "open") {
      const doorType = bay.doors.type;
      const systemId = bay.doors.systemId || inferDoorSystemIdFromType(doorType);
      const spec = DOOR_MECHANISM_SPECS[systemId];

      if (!spec.isVerified) {
        warnings.push(
          `Bölme ${bayIdx + 1} Kapak Sistemi (${spec.label}): ${spec.reasonIfUnverified}`
        );
      }

      const isDoubleLeaf =
        doorType === "double" ||
        doorType === "inset_double" ||
        spec.leafCountPerBay === 2;
      const doorCount = isDoubleLeaf ? 2 : 1;

      const isVerticalSplit = spec.kinematicType === "lift_bifold";
      const doorOpeningY0 = upperZoneStartY + doorPerimeterGap;
      const doorOpeningH = Math.max(100, upperZoneHeight - 2 * doorPerimeterGap);

      const leafW = isVerticalSplit
        ? Number((bayW - 2 * doorPerimeterGap).toFixed(2))
        : Number(((bayW - (doorCount + 1) * doorPerimeterGap) / doorCount).toFixed(2));
      const leafH = isVerticalSplit
        ? Number(((doorOpeningH - doorPerimeterGap) / 2).toFixed(2))
        : doorOpeningH;

      // Normalize opening progress [0..1] — strictly 0 if mechanism is NOT VERIFIED
      const openProgress = spec.isVerified
        ? Math.min(1, Math.max(0, doorOpenAngleDeg / (spec.maxAngleDeg || 90)))
        : 0;

      for (let d = 0; d < doorCount; d++) {
        // Resolve true hinge side for single-right, single-left, double, lift, sliding
        let hingeSide: ComponentGeometry["doorHingeSide"] = "left";
        if (spec.kinematicType === "sliding_track") {
          hingeSide = d === 0 ? "sliding_front" : "sliding_rear";
        } else if (
          spec.kinematicType === "lift_stay" ||
          spec.kinematicType === "lift_parallel" ||
          spec.kinematicType === "lift_bifold"
        ) {
          hingeSide = "top";
        } else if (
          doorType === "right" ||
          doorType === "single_right" ||
          doorType === "inset_right" ||
          doorType === "half_overlay_right"
        ) {
          hingeSide = "right";
        } else if (doorCount === 2) {
          hingeSide = d === 0 ? "left" : "right";
        }

        const baseLeafX = isVerticalSplit
          ? bayStartX + doorPerimeterGap
          : bayStartX + doorPerimeterGap + d * (leafW + doorPerimeterGap);
        const baseLeafY = isVerticalSplit
          ? doorOpeningY0 + d * (leafH + doorPerimeterGap)
          : doorOpeningY0;
        const baseLeafZ =
          systemId === "hinged_inset"
            ? depth - T
            : spec.kinematicType === "sliding_track"
            ? depth + (d === 0 ? spec.trackOffsetZMm : 2)
            : depth;

        // Calculate mechanism-specific 3D transform (rotation + translation)
        let rotX = 0;
        let rotY = 0;
        let posX = baseLeafX;
        let posY = baseLeafY;
        let posZ = baseLeafZ + explodeZ;

        const maxRad = (spec.maxAngleDeg * Math.PI) / 180;

        if (spec.kinematicType === "hinged_pivot") {
          const sign = hingeSide === "left" ? -1 : 1;
          rotY = sign * openProgress * maxRad;
        } else if (spec.kinematicType === "sliding_track") {
          const slideTravel = leafW * 0.85 * openProgress;
          posX = baseLeafX + (d === 0 ? slideTravel : -slideTravel);
        } else if (spec.kinematicType === "bi_fold") {
          // WingLine bi-fold: Leaf 0 pivots at left edge, Leaf 1 counter-folds and translates toward left edge
          const foldRad = openProgress * maxRad;
          rotY = d === 0 ? -foldRad : foldRad;
          if (d === 1) {
            posX = baseLeafX - leafW * (1 - Math.cos(foldRad));
            posZ = baseLeafZ + leafW * Math.sin(foldRad);
          }
        } else if (spec.kinematicType === "lift_stay") {
          rotX = -openProgress * maxRad;
        } else if (spec.kinematicType === "lift_parallel") {
          posY = baseLeafY + openProgress * Math.min(320, leafH * 0.65);
          posZ = baseLeafZ + Math.sin(openProgress * Math.PI * 0.5) * spec.trackOffsetZMm + explodeZ;
        } else if (spec.kinematicType === "lift_bifold") {
          // Top leaf (d === 1) swings up, bottom leaf (d === 0) folds upward with it
          const foldRad = openProgress * maxRad;
          rotX = d === 1 ? -foldRad : foldRad * 0.65;
          if (d === 0) {
            posY = baseLeafY + leafH * (1 - Math.cos(foldRad)) * 0.85;
            posZ = baseLeafZ + leafH * Math.sin(foldRad) * 0.5 + explodeZ;
          }
        }

        const pivotPos = {
          x: hingeSide === "right" ? baseLeafX + leafW : baseLeafX,
          y: hingeSide === "top" ? baseLeafY + leafH : baseLeafY + leafH / 2,
          z: baseLeafZ,
        };

        const doorLeafId = `${module.id}_door_b${bayIdx + 1}_${d + 1}`;
        components.push({
          id: doorLeafId,
          partCode: `DR${bayIdx + 1}_${d + 1}`,
          role: "door_leaf",
          label: `Kapak B${bayIdx + 1}-${d + 1} (${spec.label})`,
          bayIndex: bayIdx,
          dimensions: { width: leafW, height: leafH, depth: T },
          cutDimensions: {
            finishedLengthMm: Math.max(leafW, leafH),
            finishedWidthMm: Math.min(leafW, leafH),
            thicknessMm: T,
            grain: "vertical",
          },
          position: { x: posX, y: posY, z: posZ },
          pivotPosition: pivotPos,
          rotation: [rotX, rotY, 0],
          materialId: doorMaterialId || bodyMaterialId,
          isFrontFacing: true,
          isPanelCutPiece: true,
          doorSystemId: systemId,
          doorHingeSide: hingeSide,
          isMechanismVerified: spec.isVerified,
        });

        // --- Door Handle Generation (FAZ B: Strictly attached to correct door & opening edge) ---
        const handleProfileId = bay.doors.handleProfileId || "HRD_HANDLE_BAR_160";
        const shouldRenderHandle =
          handleProfileId !== "handleless_plain" &&
          handleProfileId !== "none" &&
          (!isVerticalSplit || d === 0); // On Aventos HF bi-fold, handle sits on the lower leaf (d=0)

        if (shouldRenderHandle) {
          const isVerticalHandle =
            hingeSide === "left" ||
            hingeSide === "right" ||
            hingeSide === "sliding_front" ||
            hingeSide === "sliding_rear";
          const handleLength = Math.min(160, Math.max(64, (isVerticalHandle ? leafH : leafW) * 0.25));
          const handleW = isVerticalHandle ? 14 : handleLength;
          const handleH = isVerticalHandle ? handleLength : 14;
          const handleD = 24;
          const edgeMarginX = 38; // Standard 38mm handle drilling setback from opening edge

          // Compute handle X on the opening edge (opposite the hinge!)
          let handleLocalX = (leafW - handleW) / 2;
          if (hingeSide === "left" || hingeSide === "sliding_front") {
            handleLocalX = Math.max(15, leafW - edgeMarginX - handleW / 2);
          } else if (hingeSide === "right" || hingeSide === "sliding_rear") {
            handleLocalX = Math.min(leafW - 25, edgeMarginX - handleW / 2);
          }

          // Compute handle Y based on module category / placement rule
          const placement = bay.doors.handlePlacement || "auto";
          let handleLocalY = (leafH - handleH) / 2;
          if (placement === "top_corner" || (placement === "auto" && module.category === "base")) {
            handleLocalY = Math.max(20, leafH - handleH - 50);
          } else if (placement === "bottom_corner" || (placement === "auto" && (module.category === "wall" || hingeSide === "top"))) {
            handleLocalY = Math.min(leafH - handleH - 20, 40);
          }

          // Transform handle position with door rotation/translation so it moves with the door leaf
          let handleWorldX = posX + handleLocalX;
          let handleWorldY = posY + handleLocalY;
          let handleWorldZ = posZ + T;

          if (spec.kinematicType === "hinged_pivot" && Math.abs(rotY) > 0.001) {
            const dxFromPivot =
              hingeSide === "left" ? handleLocalX + handleW / 2 : -(leafW - handleLocalX - handleW / 2);
            handleWorldX = pivotPos.x + dxFromPivot * Math.cos(rotY);
            handleWorldZ = pivotPos.z + Math.abs(dxFromPivot * Math.sin(rotY)) + T;
          } else if (spec.kinematicType === "lift_stay" && Math.abs(rotX) > 0.001) {
            const dyFromPivot = leafH - handleLocalY;
            handleWorldY = pivotPos.y - dyFromPivot * Math.cos(Math.abs(rotX));
            handleWorldZ = pivotPos.z + dyFromPivot * Math.sin(Math.abs(rotX)) + T;
          }

          components.push({
            id: `${doorLeafId}_handle`,
            role: "door_handle",
            label: `Kapak Kulpu B${bayIdx + 1}-${d + 1}`,
            bayIndex: bayIdx,
            parentComponentId: doorLeafId,
            hardwareRefId: handleProfileId,
            dimensions: { width: handleW, height: handleH, depth: handleD },
            position: {
              x: Number(handleWorldX.toFixed(2)),
              y: Number(handleWorldY.toFixed(2)),
              z: Number(handleWorldZ.toFixed(2)),
            },
            rotation: [rotX, rotY, 0],
            materialId: "mat_anodized_metal",
            isFrontFacing: true,
            isPanelCutPiece: false,
            doorSystemId: systemId,
            doorHingeSide: hingeSide,
            isMechanismVerified: spec.isVerified,
          });
        }
      }
    }

    bayStartX += bayW + T;
  });

  return {
    moduleId: module.id,
    overall: module.dimensions,
    components,
    bayWidths,
    netInnerHeight: netInnerH,
    netInnerDepth: netInnerD,
    warnings,
  };
}
