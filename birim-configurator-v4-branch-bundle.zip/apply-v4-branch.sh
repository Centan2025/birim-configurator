#!/usr/bin/env bash
set -euo pipefail

BRANCH_NAME="feat/configurator-parametric-engine-v4"

echo "==> [1/4] Checking git repository and switching to branch: ${BRANCH_NAME}"
git checkout -B "${BRANCH_NAME}"

echo "==> [2/4] Running standalone Node.js verification test suite..."
node --test tests/v4-parametric-engine.test.mjs

echo "==> [3/4] Staging modified and added files..."
git add packages/core/src/types.ts         packages/core/src/rules.ts         packages/geometry/src/types.ts         packages/geometry/src/mesh-generator.ts         packages/manufacturing/src/drilling-engine.ts         packages/manufacturing/src/bom-generator.ts         apps/configurator/src/v3/engine/kitchenSpatialEngine.ts         apps/configurator/src/v3/adapter/useV3Adapter.ts         tests/v4-parametric-engine.test.mjs         tests/v4-parametric-engine.test.ts         docs/configurator/GITHUB_RESEARCH.md         docs/configurator/ARCHITECTURE.md         docs/configurator/IMPLEMENTATION_REPORT.md         docs/configurator/TEST_REPORT.md         docs/configurator/LOCAL_VERIFICATION.md

git commit -m "feat(v4): unify parametric geometry engine, door/handle kinematics, 2D/3D spatial sync, and BOM verification gates"

echo "==> [4/4] Pushing branch ${BRANCH_NAME} to origin..."
git push -u origin "${BRANCH_NAME}"

echo "==> Done! Open your Pull Request at:"
echo "    https://github.com/Centan2025/birim-configurator/compare/main...${BRANCH_NAME}?expand=1"
